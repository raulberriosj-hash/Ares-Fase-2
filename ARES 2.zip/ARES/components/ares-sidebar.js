(function () {
'use strict';

/**
 * <ares-sidebar>
 *
 * Sidebar de navegación: logo + ítem "Incidentes", expandible/colapsable.
 * Ocupa 100vh por defecto; sobreescribir `height` desde afuera si hace
 * falta. Un solo ítem de navegación fijo — no es una lista configurable.
 *
 * Atributo:
 *   expandido   boolean — por defecto expandido
 *
 * Eventos:
 *   ares-toggle           click en colapsar/expandir. detail: { expandido }
 *   ares-nav-incidentes   click en el ítem "Incidentes"
 */

const LOGO_FULL =
  '<svg class="logo" viewBox="0 0 481.19 86.81" xmlns="http://www.w3.org/2000/svg" aria-label="Inelcom Chile">' +
  '<path fill="#00bdd4" d="M14.47,73.4a7.16,7.16,0,0,0-5.11-2.22A6.93,6.93,0,0,0,9.41,85a7.34,7.34,0,0,0,5.06-2.22v2.31a8.57,8.57,0,0,1-5,1.64,8.67,8.67,0,1,1,0-17.33,8.1,8.1,0,0,1,5,1.65Z"/>' +
  '<polygon fill="#00bdd4" points="72.85 76.53 72.85 69.74 74.71 69.74 74.71 86.48 72.85 86.48 72.85 78.26 64.27 78.26 64.27 86.48 62.4 86.48 62.4 69.74 64.27 69.74 64.27 76.53 72.85 76.53"/>' +
  '<rect fill="#00bdd4" x="122.92" y="69.73" width="1.87" height="16.75"/>' +
  '<polygon fill="#00bdd4" points="174.74 84.75 179.36 84.75 179.36 86.48 172.87 86.48 172.87 69.73 174.74 69.73 174.74 84.75"/>' +
  '<polygon fill="#00bdd4" points="225.9 69.73 234.58 69.73 234.58 71.47 227.76 71.47 227.76 76.44 234.38 76.44 234.38 78.18 227.76 78.18 227.76 84.75 234.58 84.75 234.58 86.49 225.9 86.49 225.9 69.73"/>' +
  '<path fill="#00bdd4" d="M381.22,15.52a9.1,9.1,0,0,0-12.9,0,8.78,8.78,0,0,0-2.63,6.42,9,9,0,0,0,2.63,6.49,9.25,9.25,0,0,0,12.9,0A8.68,8.68,0,0,0,384,21.94a8.44,8.44,0,0,0-2.74-6.42m8.93,21.78a21.72,21.72,0,0,1-30.71,0,21.2,21.2,0,0,1-6.36-15.36,21,21,0,0,1,6.36-15.35,21.57,21.57,0,0,1,30.71,0,20.82,20.82,0,0,1,6.42,15.35,21,21,0,0,1-6.42,15.36"/>' +
  '<rect fill="#00bdd4" x="344.08" y="52.63" width="61.5" height="12.61"/>' +
  '<rect fill="#00bdd4" x="354.57" y="74.2" width="40.52" height="12.61"/>' +
  '<rect fill="#ffffff" y="1.41" width="12.61" height="40.51"/>' +
  '<polygon fill="#ffffff" points="94.39 41.91 81.96 41.91 81.84 41.98 68.83 23.24 68.83 41.91 56.27 41.91 56.27 1.46 68.83 1.41 81.78 19.85 81.78 1.41 94.39 1.41 94.39 41.91"/>' +
  '<polygon fill="#ffffff" points="150.78 12.49 150.78 16.29 167.12 16.29 167.12 26.45 150.78 26.45 150.78 30.48 167.48 30.48 167.48 41.91 138.17 41.91 138.17 1.41 167.42 1.41 167.42 12.49 150.78 12.49"/>' +
  '<polygon fill="#ffffff" points="236.3 41.91 210.85 41.91 210.85 1.41 223.4 1.41 223.4 29.31 236.3 29.31 236.3 41.91"/>' +
  '<path fill="#ffffff" d="M312.43,38.88c-4.85,4-7.88,4.62-14,4.62a21,21,0,0,1-15.35-6.37,20.94,20.94,0,0,1-6.36-15.35,21,21,0,0,1,6.36-15.41A21,21,0,0,1,298.47,0a23.54,23.54,0,0,1,13.67,4.85l-7.07,10.62-.12-.11a9.15,9.15,0,0,0-13,0,8.57,8.57,0,0,0-2.68,6.42,8,8,0,0,0,2.33,6.3,9.37,9.37,0,0,0,6.83,2.51c2.51,0,5.37-.4,7.19-2.21l.17-.18,7.88,9.4Z"/>' +
  '<polygon fill="#ffffff" points="481.19 1.41 481.19 41.91 468.64 41.91 468.64 22.3 460.06 33.69 451.3 22.13 451.3 41.91 438.75 41.91 438.75 1.41 451.3 1.41 451.3 1.46 451.36 1.46 460 12.79 468.64 1.52 468.64 1.41 481.19 1.41"/>' +
  '</svg>';

const LOGO_COMPACT =
  '<svg class="logo-compact" viewBox="0 0 252.22 301.19" xmlns="http://www.w3.org/2000/svg"><rect fill="#1c1c1c" width="252.22" height="301.19"/><path fill="#00bdd4" d="M141.45,83.51A21.78,21.78,0,0,0,104.2,98.9a21.57,21.57,0,0,0,6.3,15.55,22.16,22.16,0,0,0,30.95,0A20.74,20.74,0,0,0,148,98.9a20.22,20.22,0,0,0-6.56-15.39m21.41,52.22C152.64,145.81,140.46,151,126,151s-26.6-5.18-36.82-15.26S74,113.19,74,98.9A50.29,50.29,0,0,1,89.22,62.09C99.44,51.87,111.62,46.68,126,46.68s26.6,5.19,36.82,15.41A49.89,49.89,0,0,1,178.27,98.9c0,14.29-5.19,26.61-15.41,36.83"/><rect fill="#00bdd4" x="52.35" y="172.51" width="147.53" height="30.25"/><rect fill="#00bdd4" x="77.52" y="224.26" width="97.18" height="30.24"/></svg>';

const COLLAPSE_ICON =
  '<svg width="11" height="19" viewBox="0 0 10.8412 18.9647" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.4724 0.367234C10.3563 0.250826 10.2184 0.158469 10.0665 0.095453C9.91467 0.0324369 9.75186 0 9.58744 0C9.42303 0 9.26022 0.0324369 9.10836 0.095453C8.9565 0.158469 8.81856 0.250826 8.70244 0.367234L0.292444 8.77723C0.19974 8.86975 0.126193 8.97964 0.0760112 9.10061C0.0258297 9.22158 0 9.35127 0 9.48223C0 9.6132 0.0258297 9.74288 0.0760112 9.86386C0.126193 9.98483 0.19974 10.0947 0.292444 10.1872L8.70244 18.5972C9.19244 19.0872 9.98244 19.0872 10.4724 18.5972C10.9624 18.1072 10.9624 17.3172 10.4724 16.8272L3.13244 9.48723L10.4824 2.13723C10.9624 1.64723 10.9624 0.857234 10.4724 0.367234Z" fill="currentColor"/></svg>';

const NAV_ICON =
  '<svg width="24" height="24" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 2H11.82C11.4 0.84 10.3 0 9 0C7.7 0 6.6 0.84 6.18 2H2C1.86 2 1.73 2.01 1.6 2.04C1.28158 2.10698 0.984181 2.25027 0.733356 2.45755C0.48253 2.66483 0.285777 2.9299 0.16 3.23C0.0600001 3.46 0 3.72 0 4V18C0 18.27 0.0600001 18.54 0.16 18.78C0.26 19.02 0.41 19.23 0.59 19.42C0.86 19.69 1.21 19.89 1.6 19.97C1.73 19.99 1.86 20 2 20H16C17.1 20 18 19.1 18 18V4C18 2.9 17.1 2 16 2ZM9 1.75C9.41 1.75 9.75 2.09 9.75 2.5C9.75 2.91 9.41 3.25 9 3.25C8.59 3.25 8.25 2.91 8.25 2.5C8.25 2.09 8.59 1.75 9 1.75ZM16 18H2V4H16V18Z" fill="currentColor"/></svg>';

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: block;
      height: 100vh;
      font-family: var(--font-family-base);
    }
    .sidebar {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: var(--space-6);
      width: 200px;
      height: 100%;
      padding: var(--space-6);
      background: var(--color-bg-inverse);
      box-shadow: 1px 0px 8.6px 2px rgba(0, 0, 0, 0.36);
      box-sizing: border-box;
      transition: width 0.15s ease;
    }
    :host(:not([expandido])) .sidebar {
      width: 75px;
      padding-left: var(--space-2);
      padding-right: var(--space-2);
    }
    .logo-wrap {
      width: 100%;
      display: flex;
      justify-content: center;
    }
    .logo {
      width: 100%;
      height: auto;
      display: block;
    }
    .logo-compact {
      display: none;
      width: 32px;
      height: auto;
      flex-shrink: 0;
    }
    :host(:not([expandido])) .logo {
      display: none;
    }
    :host(:not([expandido])) .logo-compact {
      display: block;
    }
    .nav-item {
      display: flex;
      align-items: center;
      gap: var(--space-2);
      width: 100%;
      padding: var(--space-3);
      background: var(--color-bg-primary);
      border-radius: var(--radius-lg);
      color: var(--color-text-primary);
      cursor: pointer;
      box-sizing: border-box;
      border: none;
      font-family: var(--font-family-base);
    }
    .nav-item svg {
      flex-shrink: 0;
    }
    .nav-item:hover {
      background: var(--color-bg-secondary);
    }
    .nav-item:active {
      background: var(--color-bg-tertiary);
    }
    .nav-label {
      font-size: var(--font-size-base);
      font-weight: var(--font-weight-bold);
      white-space: nowrap;
    }
    :host(:not([expandido])) .nav-item {
      justify-content: center;
    }
    :host(:not([expandido])) .nav-label {
      display: none;
    }
    .toggle {
      all: unset;
      position: absolute;
      top: 52px;
      right: -30px;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 60px;
      background: var(--color-bg-inverse);
      color: var(--color-text-inverse);
      border-radius: 0 var(--radius-md) var(--radius-md) 0;
      cursor: pointer;
      box-sizing: border-box;
    }
    .toggle:hover {
      background: var(--color-neutral-800);
    }
    .toggle:active {
      background: var(--color-neutral-700);
    }
    .toggle svg {
      transition: transform 0.15s ease;
    }
    :host(:not([expandido])) .toggle svg {
      transform: rotate(180deg);
    }
  </style>
  <div class="sidebar">
    <div class="logo-wrap">
      ${LOGO_FULL}
      ${LOGO_COMPACT}
    </div>
    <button type="button" class="nav-item">
      ${NAV_ICON}
      <span class="nav-label">Incidentes</span>
    </button>
    <button type="button" class="toggle" aria-label="Colapsar/expandir menú">${COLLAPSE_ICON}</button>
  </div>
`;

class AresSidebar extends HTMLElement {
  static get observedAttributes() {
    return ['expandido'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this.shadowRoot.querySelector('.toggle').addEventListener('click', () => {
      const expandido = !this.hasAttribute('expandido');
      this.toggleAttribute('expandido', expandido);
      this.dispatchEvent(new CustomEvent('ares-toggle', { detail: { expandido }, bubbles: true, composed: true }));
    });
    this.shadowRoot.querySelector('.nav-item').addEventListener('click', () => {
      this.dispatchEvent(new CustomEvent('ares-nav-incidentes', { bubbles: true, composed: true }));
    });
  }

  connectedCallback() {
    if (!this.hasAttribute('expandido') && this.getAttribute('expandido') !== 'false') {
      this.setAttribute('expandido', '');
    }
  }
}

if (!customElements.get('ares-sidebar')) {
  customElements.define('ares-sidebar', AresSidebar);
}
})();
