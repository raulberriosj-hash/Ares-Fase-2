(function () {
'use strict';

/**
 * <ares-alarm-row>
 *
 * Fila de la tabla de alarmas en el detalle de gestión de incidencia.
 *
 * Tipo de dato: AlarmRowData (ver types.js).
 *
 * Eventos:
 *   ares-ver-evidencia   click en el ícono de evidencia (si no está
 *                        deshabilitado). detail: { id }
 */

const FLAG_ICONS = {
  dyinggasp:
    '<svg width="14" height="14" viewBox="0 0 13.6125 14.2425" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.4675 0H3.9675V1.41L5.4675 2.91V0ZM9.9675 4.5V7.41L11.3175 8.76L11.4675 8.61V4.5C11.4675 3.675 10.7925 3 9.9675 3V0H8.4675V3H5.5575L7.0575 4.5H9.9675ZM1.0575 0.63L0 1.6875L2.4675 4.155V8.625L5.0925 11.25V13.5H8.8425V11.25L9.2025 10.89L12.555 14.2425L13.6125 13.185L1.0575 0.63ZM7.3425 10.6275V12H6.5925V10.6275L3.9675 7.9875V5.655L8.145 9.8325L7.3425 10.6275Z" fill="currentColor"/></svg>',
  inconsistency:
    '<svg width="14" height="13" viewBox="0 0 14.2971 12.7556" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.14853 1.49813L12.796 11.2556H1.50103L7.14853 1.49813ZM0.203528 10.5056C-0.373972 11.5031 0.346028 12.7556 1.50103 12.7556H12.796C13.951 12.7556 14.671 11.5031 14.0935 10.5056L8.44603 0.748125C7.86853 -0.249375 6.42853 -0.249375 5.85103 0.748125L0.203528 10.5056ZM6.39853 5.25563V6.75563C6.39853 7.16813 6.73603 7.50563 7.14853 7.50563C7.56103 7.50563 7.89853 7.16813 7.89853 6.75563V5.25563C7.89853 4.84313 7.56103 4.50563 7.14853 4.50563C6.73603 4.50563 6.39853 4.84313 6.39853 5.25563ZM6.39853 9.00563H7.89853V10.5056H6.39853V9.00563Z" fill="currentColor"/></svg>',
  'different-integration':
    '<svg width="11" height="11" viewBox="0 0 11.25 11.25" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.25 1.0575L10.1925 0L1.5 8.6925V3.75H0V11.25H7.5V9.75H2.5575L11.25 1.0575Z" fill="currentColor"/></svg>',
};

const EVIDENCE_ICON =
  '<svg width="20" height="20" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 13.3333V1.66667C15 0.75 14.25 0 13.3333 0H1.66667C0.75 0 0 0.75 0 1.66667V13.3333C0 14.25 0.75 15 1.66667 15H13.3333C14.25 15 15 14.25 15 13.3333ZM4.58333 8.75L6.66667 11.2583L9.58333 7.5L13.3333 12.5H1.66667L4.58333 8.75Z" fill="currentColor"/></svg>';

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: block;
      font-family: var(--font-family-base);
    }
    .row {
      display: flex;
      align-items: center;
      gap: var(--space-3);
      padding: var(--space-3);
      background: var(--color-bg-primary);
      border-bottom: 1px solid var(--color-border-default);
    }
    :host(:hover) .row {
      background: var(--color-bg-secondary);
    }
    .col {
      flex: 1 0 0;
      min-width: 0;
    }
    .id-col {
      /* Más ancho que las demás columnas (flex-grow 1.8 vs 1 — ver la
         misma proporción en .alarm-head-row de gestion-incidencia.html)
         para que el ID completo y los flags quepan en una sola fila sin
         invadir la columna "Creado". Sin overflow:hidden acá: recortaría
         el popover de ares-tooltip-flag. */
      display: flex;
      flex: 1.8 0 0;
      align-items: center;
      gap: var(--space-2);
      min-width: 0;
    }
    .id {
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
      white-space: nowrap;
    }
    .flags {
      display: inline-flex;
      flex-shrink: 0;
      gap: var(--space-1);
    }
    .text-col {
      font-size: var(--font-size-xs);
      color: var(--color-text-secondary);
      text-align: center;
    }
    .status-col {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: center;
      gap: var(--space-2);
    }
    .status-date {
      font-size: var(--font-size-xs);
      color: var(--color-text-secondary);
    }
    .action-col {
      /* flex-basis fijo, igual al de la última columna de .alarm-head-row
         en gestion-incidencia.html, para que las columnas queden alineadas. */
      display: flex;
      justify-content: flex-end;
      flex: 0 0 60px;
    }
  </style>
  <div class="row">
    <div class="col id-col">
      <span class="id"></span>
      <span class="flags"></span>
    </div>
    <div class="col text-col created"></div>
    <div class="col status-col">
      <ares-alarma-badge></ares-alarma-badge>
      <span class="status-date"></span>
    </div>
    <div class="col text-col ci"></div>
    <div class="action-col">
      <ares-icon-button variant="brand" label="Ver evidencia" tooltip="Ver imagen de evidencia">${EVIDENCE_ICON}</ares-icon-button>
    </div>
  </div>
`;

class AresAlarmRow extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._data = null;
    this._els = {
      id: this.shadowRoot.querySelector('.id'),
      flags: this.shadowRoot.querySelector('.flags'),
      created: this.shadowRoot.querySelector('.created'),
      badge: this.shadowRoot.querySelector('ares-alarma-badge'),
      statusDate: this.shadowRoot.querySelector('.status-date'),
      ci: this.shadowRoot.querySelector('.ci'),
      evidenceBtn: this.shadowRoot.querySelector('ares-icon-button'),
    };
    this._upgradeProperty('data');
    this._els.evidenceBtn.addEventListener('click', () => {
      if (this._els.evidenceBtn.hasAttribute('disabled')) return;
      this.dispatchEvent(
        new CustomEvent('ares-ver-evidencia', {
          detail: { id: this._data?.id },
          bubbles: true,
          composed: true,
        })
      );
    });
  }

  // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
  _upgradeProperty(prop) {
    if (Object.prototype.hasOwnProperty.call(this, prop)) {
      const value = this[prop];
      delete this[prop];
      this[prop] = value;
    }
  }

  /** @param {import('../types.js').AlarmRowData} value */
  set data(value) {
    this._data = value;
    this._render();
  }

  get data() {
    return this._data;
  }

  _render() {
    const d = this._data;
    if (!d) return;

    this._els.id.textContent = d.id;
    this._els.created.textContent = d.creado;
    this._els.badge.setAttribute('estado', d.estado);
    this._els.statusDate.textContent = d.estadoFecha;
    this._els.ci.textContent = d.ciAfectado;

    this._els.flags.innerHTML = '';
    (d.flags || []).forEach((type) => {
      const flag = document.createElement('ares-tooltip-flag');
      flag.setAttribute('type', type);
      if (type === 'different-integration' && d.creadorAlarma) {
        flag.setAttribute('creador', d.creadorAlarma);
      }
      flag.innerHTML = FLAG_ICONS[type] || '';
      this._els.flags.appendChild(flag);
    });

    if (d.evidenciaDisponible) {
      this._els.evidenceBtn.removeAttribute('disabled');
    } else {
      this._els.evidenceBtn.setAttribute('disabled', '');
    }
  }
}

if (!customElements.get('ares-alarm-row')) {
  customElements.define('ares-alarm-row', AresAlarmRow);
}
})();
