(function () {
'use strict';

/**
 * <ares-gestor-badge>
 *
 * Badge de cobertura de evidencia por fabricante, en el bloque "Evidencia"
 * del detalle de incidencia.
 *
 * Atributo:
 *   fabricante   "nokia" | "uaa" | "huawei" | "sin-respuesta"
 *
 * Slot:
 *   (default)  texto con el conteo, ej. "Nokia · 38" (DATA-INPUT)
 */

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      font-family: var(--font-family-base);
    }

    .badge {
      display: inline-flex;
      align-items: center;
      gap: var(--space-1);
      padding: var(--space-1) var(--space-2);
      background: var(--color-bg-primary);
      border: 1px solid var(--color-border-strong);
      border-radius: var(--radius-md);
      /* ::slotted(*) no matchea texto plano — se fija acá en vez de ahí. */
      font-size: var(--font-size-xs);
      line-height: var(--line-height-caption);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-secondary);
      white-space: nowrap;
    }

    .dot {
      width: 6px;
      height: 6px;
      border-radius: var(--radius-full);
      flex-shrink: 0;
      background: var(--color-corporate-500);
    }

    :host([fabricante="sin-respuesta"]) .dot {
      background: var(--color-error-600);
    }
    :host([fabricante="sin-respuesta"]) .badge {
      color: var(--color-text-error);
    }
  </style>
  <span class="badge">
    <span class="dot"></span>
    <slot></slot>
  </span>
`;

class AresGestorBadge extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
  }
}

if (!customElements.get('ares-gestor-badge')) {
  customElements.define('ares-gestor-badge', AresGestorBadge);
}
})();
