(function () {
'use strict';

/**
 * <ares-assignment-modal>
 *
 * Modal de confirmación al tomar una incidencia ("Tomar INC").
 *
 * Atributos:
 *   open   boolean — controla visibilidad
 *   modo   "confirmar" | "cambio"
 *
 * Tipo de dato: AssignmentModalData (ver types.js).
 *
 * Eventos:
 *   ares-cancel     click en "Cancelar" o en el ícono de cierre
 *   ares-gestionar  click en "Gestionar". detail: { id }
 */

const CLOSE_ICON =
  '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.33333"/></svg>';

const TEMPLATE = document.createElement("template");
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: none;
      font-family: var(--font-family-base);
    }
    :host([open]) {
      display: flex;
      position: fixed;
      inset: 0;
      align-items: center;
      justify-content: center;
      padding: var(--space-4);
      background: var(--color-overlay-modal);
      z-index: 1000;
      box-sizing: border-box;
    }
    .dialog {
      display: flex;
      flex-direction: column;
      width: min(94vw, 1040px);
      max-height: 88vh;
      overflow: auto;
      background: var(--color-bg-primary);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-modal);
    }
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: var(--space-3);
      padding: var(--space-6);
      border-bottom: 1px solid var(--color-border-default);
    }
    .header h2 {
      margin: 0;
      font-size: var(--font-size-h3);
      line-height: var(--line-height-h3);
      letter-spacing: var(--letter-spacing-h3);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
    }
    .body {
      display: flex;
      flex-direction: column;
      gap: var(--space-6);
      padding: var(--space-6);
      background: var(--color-bg-tertiary);
    }
    .body p {
      margin: 0;
      font-size: var(--font-size-base);
      line-height: var(--line-height-base);
      color: var(--color-text-primary);
    }
    .desc-confirmar,
    .warning {
      display: none;
    }
    :host(:not([modo="cambio"])) .desc-confirmar {
      display: block;
    }
    :host([modo="cambio"]) .warning {
      display: block;
    }
    .actions {
      display: flex;
      justify-content: flex-end;
      gap: var(--space-2);
    }
  </style>
  <div class="dialog" role="dialog" aria-modal="true">
    <div class="header">
      <h2 class="title"></h2>
      <ares-icon-button class="btn-close" variant="neutral" label="Cerrar">${CLOSE_ICON}</ares-icon-button>
    </div>
    <div class="body">
      <p class="desc-confirmar">Vas a asignarte la siguiente incidencia para realizar su gestión.</p>
      <p class="warning">Ya posees una incidencia asignada:</p>
      <ares-incident-row class="summary-actual" compacta variante="en-curso" style="display:none"></ares-incident-row>
      <p class="warning">Al asignarte esta nueva incidencia, tu incidencia actual volverá a la cola de pendientes y podrá ser tomada por otra persona.</p>
      <ares-incident-row class="summary-nueva" compacta variante="pendiente"></ares-incident-row>
      <div class="actions">
        <ares-button class="btn-cancel">Cancelar</ares-button>
        <ares-button class="btn-gestionar" intent="primary">Gestionar<svg slot="icon-end" width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 0L4.11875 0.88125L7.60625 4.375H0V5.625H7.60625L4.11875 9.11875L5 10L10 5L5 0Z" fill="currentColor"/></svg></ares-button>
      </div>
    </div>
  </div>
`;

class AresAssignmentModal extends HTMLElement {
  static get observedAttributes() {
    return ["modo"];
  }

  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._data = null;
    this._els = {
      title: this.shadowRoot.querySelector(".title"),
      summaryActual: this.shadowRoot.querySelector(".summary-actual"),
      summaryNueva: this.shadowRoot.querySelector(".summary-nueva"),
      btnClose: this.shadowRoot.querySelector(".btn-close"),
      btnCancel: this.shadowRoot.querySelector(".btn-cancel"),
      btnGestionar: this.shadowRoot.querySelector(".btn-gestionar"),
    };
    const cancel = () =>
      this.dispatchEvent(
        new CustomEvent("ares-cancel", { bubbles: true, composed: true }),
      );
    this._els.btnClose.addEventListener("click", cancel);
    this._els.btnCancel.addEventListener("click", cancel);
    this._els.btnGestionar.addEventListener("click", () => {
      this.dispatchEvent(
        new CustomEvent("ares-gestionar", {
          detail: { id: this._data?.incidenciaNueva?.id },
          bubbles: true,
          composed: true,
        }),
      );
    });
    this._upgradeProperty("data");
  }

  connectedCallback() {
    this._syncModo();
  }

  attributeChangedCallback() {
    this._syncModo();
  }

  // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
  _upgradeProperty(prop) {
    if (Object.prototype.hasOwnProperty.call(this, prop)) {
      const value = this[prop];
      delete this[prop];
      this[prop] = value;
    }
  }

  /** @param {import('../types.js').AssignmentModalData} value */
  set data(value) {
    this._data = value;
    this._render();
  }

  get data() {
    return this._data;
  }

  _syncModo() {
    const modo = this.getAttribute("modo") || "confirmar";
    this._els.title.textContent =
      modo === "cambio"
        ? "Cambio de asignación de Incidencia"
        : "Confirma asignación de incidencia";
    this._els.summaryActual.style.display = modo === "cambio" ? "" : "none";
  }

  _render() {
    const d = this._data;
    if (!d) return;
    /* Fase 2: las filas del modal son <ares-incident-row> en modo compacto,
       el mismo componente que usa la bandeja (antes eran
       <ares-incident-summary>, que quedó desalineado con el diseño nuevo).
       Ese componente espera IncidentRowData, no IncidentSummary. */
    this._els.summaryNueva.data = { incidencia: d.incidenciaNueva };
    if (d.incidenciaActual) {
      this._els.summaryActual.data = {
        incidencia: d.incidenciaActual,
        responsable: d.incidenciaActual.responsable,
        esPropia: true, // la incidencia que el usuario ya tiene tomada
      };
    }
  }
}

if (!customElements.get("ares-assignment-modal")) {
  customElements.define("ares-assignment-modal", AresAssignmentModal);
}
})();
