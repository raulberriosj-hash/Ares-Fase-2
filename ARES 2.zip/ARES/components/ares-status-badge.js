(function () {
  "use strict";

  /**
   * <ares-status-badge>
   *
   * Badge de estado de una incidencia.
   *
   * Atributo:
   *   status   "pendiente" | "en-curso" | "evidencia-aprobada" |
   *            "evidencia-rechazada" | "correlacion-aprobada" |
   *            "correlacion-rechazada"
   *
   * Fase 2 (ver DIFF-FASE2.md, M1): la aprobación pasó a tener dos etapas
   * (primero Evidencia, después Correlación), así que los estados "aprobada"
   * y "rechazada" de Fase 1 se dividieron en cuatro. Además "pendiente" y
   * "en-curso" cambiaron de texto ("Pendiente" → "Gestión Pendiente").
   *
   * El estado "finalizada" que existía en el Figma de Fase 1 nunca se
   * implementó y en Fase 2 ya no existe — no se agrega.
   */

  const LABELS = {
    pendiente: "Gestión Pendiente",
    "en-curso": "Gestión en Curso",
    "evidencia-aprobada": "Evidencia Aprobada",
    "evidencia-rechazada": "Evidencia Rechazada",
    "correlacion-aprobada": "Correlación Aprobada",
    "correlacion-rechazada": "Correlación Rechazada",

    /* DEPRECADOS — estados de Fase 1. Se mantienen solo para que las
       pantallas actuales (que todavía leen 'aprobada'/'rechazada' desde
       los mocks) no se rompan mientras no se migren. Eliminar cuando
       mock-data-bandeja.js y mock-data-gestion.js usen los 4 estados
       nuevos. */
    aprobada: "Aprobada",
    rechazada: "Rechazada",
  };

  const TEMPLATE = document.createElement("template");
  TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      align-items: center;
      gap: var(--space-1);
      font-family: var(--font-family-base);
    }

    .dot {
      width: 10px;
      height: 10px;
      border-radius: var(--radius-full);
      flex-shrink: 0;
    }

    .label {
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
      font-weight: var(--font-weight-bold);
      white-space: nowrap;
    }

    /* morado — gestión pendiente */
    :host([status="pendiente"]) .dot { background: var(--color-support-500); }
    :host([status="pendiente"]) .label { color: var(--color-text-info); }

    /* naranja — gestión en curso */
    :host([status="en-curso"]) .dot { background: var(--color-warning-500); }
    :host([status="en-curso"]) .label { color: var(--color-text-warning); }

    /* verde — cualquier etapa aprobada */
    :host([status="evidencia-aprobada"]) .dot,
    :host([status="correlacion-aprobada"]) .dot,
    :host([status="aprobada"]) .dot { background: var(--color-success-500); }
    :host([status="evidencia-aprobada"]) .label,
    :host([status="correlacion-aprobada"]) .label,
    :host([status="aprobada"]) .label { color: var(--color-text-success); }

    /* rojo — cualquier etapa rechazada */
    :host([status="evidencia-rechazada"]) .dot,
    :host([status="correlacion-rechazada"]) .dot,
    :host([status="rechazada"]) .dot { background: var(--color-error-500); }
    :host([status="evidencia-rechazada"]) .label,
    :host([status="correlacion-rechazada"]) .label,
    :host([status="rechazada"]) .label { color: var(--color-text-error); }
  </style>
  <span class="dot"></span>
  <span class="label"></span>
`;

  class AresStatusBadge extends HTMLElement {
    static get observedAttributes() {
      return ["status"];
    }

    constructor() {
      super();
      this.attachShadow({ mode: "open" });
      this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
      this._label = this.shadowRoot.querySelector(".label");
    }

    connectedCallback() {
      this._sync();
    }

    attributeChangedCallback() {
      this._sync();
    }

    _sync() {
      this._label.textContent = LABELS[this.getAttribute("status")] || "";
    }
  }

  if (!customElements.get("ares-status-badge")) {
    customElements.define("ares-status-badge", AresStatusBadge);
  }
})();
