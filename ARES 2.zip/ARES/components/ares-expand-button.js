(function () {
  'use strict';

  /**
   * <ares-expand-button>
   *
   * Control para expandir/colapsar una fila de bandeja que agrupa
   * incidencias hijas (una "Consolidación"). Va a la izquierda del ID.
   *
   * Nuevo en Fase 2 (ver DIFF-FASE2.md, N4 — `button/opentable`, 2047:3484).
   *
   * Nota de naming: en Figma la variante teal con el chevron hacia abajo se
   * llama `focus`, pero funcionalmente NO es el estado de foco del teclado
   * — es el estado **expandido** (es la que se ve en la fila desplegada,
   * `2030:5049`). Acá se implementa como `expandido` para que el nombre
   * diga lo que hace; el foco real lo maneja :focus-visible.
   *
   * Atributos:
   *   expandido   booleano. Chevron hacia abajo + fondo de marca.
   *   disabled    booleano. La fila es "Individual" (no agrupa nada), así
   *               que no hay nada que expandir: se degrada a un punto gris,
   *               igual que en Figma.
   *   label       texto del aria-label. Default: "Expandir incidencias".
   *
   * Evento:
   *   ares-toggle-expandir   detail: { expandido }  (no se emite si disabled)
   */

  const CHEVRON = `
    <svg class="chevron" width="14" height="14" viewBox="0 0 24 24" fill="none"
         xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M9 5l7 7-7 7" stroke="currentColor" stroke-width="2.5"
            stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;

  const TEMPLATE = document.createElement('template');
  TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      font-family: var(--font-family-base);
    }

    /* Colores tomados del propio Figma (muestreo de las 4 variantes de
       tabla/row_desplegable_consolidacion_pendiente):
         default #F1F7F9 · hover #E3EBEF · pressed #CCDAE0 · expandido #A2F9FF */
    button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 24px;
      height: 24px;
      padding: 0;
      border: none;
      border-radius: var(--radius-sm);
      background: var(--color-bg-tertiary);
      color: var(--color-icon-primary);
      cursor: pointer;
      transition: background 120ms ease, transform 120ms ease;
    }

    button:hover { background: var(--color-bg-quaternary); }
    button:active { background: var(--color-border-strong); }

    /* El botón también reacciona cuando se pasa/presiona sobre la fila
       entera, porque en Figma toda la card es el área interactiva. La fila
       refleja su propio estado en el host vía estos atributos. */
    :host([fila-hover]) button { background: var(--color-bg-quaternary); }
    :host([fila-pressed]) button { background: var(--color-border-strong); }

    button:focus-visible {
      outline: 2px solid var(--color-border-focus);
      outline-offset: 2px;
    }

    /* El chevron apunta a la derecha colapsado y rota 90° al expandir,
       así no hacen falta dos íconos distintos. */
    .chevron { transition: transform 120ms ease; }

    /* Expandido gana sobre hover/pressed de la fila. */
    :host([expandido]) button,
    :host([expandido][fila-hover]) button,
    :host([expandido][fila-pressed]) button {
      background: var(--color-corporate-200);
      color: var(--color-text-primary);
    }
    :host([expandido]) .chevron { transform: rotate(90deg); }

    /* Fila "Individual": no hay hijas, así que el control se degrada a un
       punto gris no interactivo (mismo tratamiento que en Figma). */
    .punto { display: none; }

    :host([disabled]) button {
      background: none;
      cursor: default;
    }
    :host([disabled]) .chevron { display: none; }
    :host([disabled]) .punto {
      display: block;
      width: 6px;
      height: 6px;
      border-radius: var(--radius-full);
      background: var(--color-icon-disabled);
    }
  </style>
  <button type="button">
    ${CHEVRON}
    <span class="punto"></span>
  </button>
`;

  class AresExpandButton extends HTMLElement {
    static get observedAttributes() {
      return ['expandido', 'disabled', 'label'];
    }

    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
      this._btn = this.shadowRoot.querySelector('button');
      this._upgradeProperty('expandido');

      this._btn.addEventListener('click', () => {
        if (this.hasAttribute('disabled')) return;
        const expandido = !this.hasAttribute('expandido');
        this.toggleAttribute('expandido', expandido);
        this.dispatchEvent(
          new CustomEvent('ares-toggle-expandir', {
            detail: { expandido },
            bubbles: true,
            composed: true,
          })
        );
      });
    }

    // Recupera la propiedad si se asignó antes de que el elemento hiciera upgrade.
    _upgradeProperty(prop) {
      if (Object.prototype.hasOwnProperty.call(this, prop)) {
        const value = this[prop];
        delete this[prop];
        this[prop] = value;
      }
    }

    set expandido(v) {
      this.toggleAttribute('expandido', !!v);
    }

    get expandido() {
      return this.hasAttribute('expandido');
    }

    connectedCallback() {
      this._sync();
    }

    attributeChangedCallback() {
      this._sync();
    }

    _sync() {
      const disabled = this.hasAttribute('disabled');
      this._btn.disabled = disabled;
      this._btn.setAttribute('aria-expanded', String(this.hasAttribute('expandido')));
      this._btn.setAttribute(
        'aria-label',
        this.getAttribute('label') || 'Expandir incidencias'
      );
    }
  }

  if (!customElements.get('ares-expand-button')) {
    customElements.define('ares-expand-button', AresExpandButton);
  }
})();
