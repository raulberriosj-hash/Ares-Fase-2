(function () {
  'use strict';

  /**
   * <ares-correlated-row>
   *
   * Fila de una incidencia HIJA dentro de una consolidación. Aparece en dos
   * lugares, con el mismo contenido:
   *   - dentro de <ares-incident-row> cuando la fila padre está expandida
   *     (Figma `tabla/row_detalles_indicencias_correlacionadas`, 2089:5030);
   *   - en la tabla "Incidencias Correlacionadas" del detalle.
   *
   * Nuevo en Fase 2 (ver DIFF-FASE2.md, N1/N4).
   *
   * Se compone de átomos ya existentes en vez de reimplementar nada:
   *   <ares-problema-tag>       tipo de incidente
   *   <ares-confiabilidad-tag>  score de correlación
   *   <ares-button>             "Detalles"
   *
   * Atributo:
   *   sin-conector   oculta el conector de árbol "└" de la izquierda. Se usa
   *                  en la tabla del detalle, donde las hijas se listan
   *                  planas y no colgando de un padre visible.
   *
   * Tipo de dato: IncidenciaCorrelacionada (ver types.js).
   *
   * Evento:
   *   ares-detalles-hija   detail: { id }
   *   Nombre distinto a `ares-detalles` a propósito: ambas filas conviven en
   *   el DOM y los eventos son composed, así que si compartieran nombre el
   *   consumidor no podría distinguir si le pidieron el detalle del padre o
   *   el de una hija.
   */

  const TEMPLATE = document.createElement('template');
  TEMPLATE.innerHTML = `
  <style>
    :host {
      display: block;
      font-family: var(--font-family-base);
    }

    .wrap {
      display: flex;
      align-items: center;
      gap: var(--space-2);
    }

    /* Conector de árbol. Figma lo tiene como ícono suelto (ic/sub, 2047:3405);
       acá se dibuja con bordes: es una esquina, no vale un asset por eso. */
    .conector {
      flex: 0 0 12px;
      height: 18px;
      margin-right: var(--space-1);
      border-left: 1px solid var(--color-border-strong);
      border-bottom: 1px solid var(--color-border-strong);
      border-bottom-left-radius: var(--radius-sm);
    }
    :host([sin-conector]) .conector { display: none; }

    .row {
      flex: 1;
      display: flex;
      align-items: center;
      gap: var(--space-3);
      padding: var(--space-3) var(--space-4);
      background: var(--color-bg-primary);
      border: 1px solid var(--color-border-default);
      border-radius: var(--radius-md);
      min-width: 0;
    }
    :host(:hover) .row {
      border-color: var(--color-border-strong);
    }

    .id {
      flex: 0 0 auto;
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
      white-space: nowrap;
    }

    .campo {
      font-size: var(--font-size-xs);
      color: var(--color-text-tertiary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .campo b {
      font-weight: var(--font-weight-bold);
      color: var(--color-text-secondary);
    }

    /* Agrupados a la izquierda: es .fin quien empuja hacia la derecha con
       su margin-left:auto. Si estas dos crecieran, quedarían separadas
       entre sí en vez de leerse como un bloque. */
    .olt { flex: 0 1 auto; min-width: 0; }
    .puerto { flex: 0 1 auto; min-width: 0; }

    /* Empuja score + botón contra el borde derecho. */
    .fin {
      margin-left: auto;
      display: flex;
      align-items: center;
      gap: var(--space-4);
      flex: 0 0 auto;
    }
  </style>
  <div class="wrap">
    <span class="conector" aria-hidden="true"></span>
    <div class="row">
      <span class="id"></span>
      <ares-problema-tag></ares-problema-tag>
      <span class="campo olt">OLT <b class="olt-val"></b></span>
      <span class="campo puerto">Puerto <b class="puerto-val"></b></span>
      <div class="fin">
        <ares-confiabilidad-tag></ares-confiabilidad-tag>
        <ares-button class="btn-detalles">Detalles</ares-button>
      </div>
    </div>
  </div>
`;

  class AresCorrelatedRow extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
      this._data = null;
      this._els = {
        id: this.shadowRoot.querySelector('.id'),
        tag: this.shadowRoot.querySelector('ares-problema-tag'),
        olt: this.shadowRoot.querySelector('.olt-val'),
        puerto: this.shadowRoot.querySelector('.puerto-val'),
        confiabilidad: this.shadowRoot.querySelector('ares-confiabilidad-tag'),
      };
      this._upgradeProperty('data');

      this.shadowRoot.querySelector('.btn-detalles').addEventListener('click', () => {
        this.dispatchEvent(
          new CustomEvent('ares-detalles-hija', {
            detail: { id: this._data?.id },
            bubbles: true,
            composed: true,
          })
        );
      });
    }

    // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
    _upgradeProperty(prop) {
      if (Object.prototype.hasOwnProperty.call(this, prop)) {
        const value = this[prop];
        delete this[prop];
        this[prop] = value;
      }
    }

    /** @param {import('../types.js').IncidenciaCorrelacionada} value */
    set data(value) {
      this._data = value;
      this._render();
    }

    get data() {
      return this._data;
    }

    _render() {
      const d = this._data;
      if (!d) return;

      this._els.id.textContent = d.id;
      this._els.tag.setAttribute('tipo', d.tipoIncidente);
      this._els.olt.textContent = d.olt;
      this._els.puerto.textContent = d.puerto;

      // Sin score no se muestra el tag: es preferible a "Confiabilidad %".
      if (d.confiabilidad === undefined || d.confiabilidad === null) {
        this._els.confiabilidad.style.display = 'none';
      } else {
        this._els.confiabilidad.style.display = '';
        this._els.confiabilidad.setAttribute('valor', d.confiabilidad);
      }
    }
  }

  if (!customElements.get('ares-correlated-row')) {
    customElements.define('ares-correlated-row', AresCorrelatedRow);
  }
})();
