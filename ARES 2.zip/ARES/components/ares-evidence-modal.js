(function () {
'use strict';

/**
 * <ares-evidence-modal>
 *
 * Visor de imagen de evidencia de una alarma. Si `imagenUrl` no se
 * provee, muestra un placeholder.
 *
 * Atributo:
 *   open   boolean — controla visibilidad
 *
 * Tipo de dato: EvidenceModalData (ver types.js).
 *
 * Eventos:
 *   ares-cancel   click en el ícono de cierre
 */

const CLOSE_ICON =
  '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.33333"/></svg>';

const PLACEHOLDER_ICON =
  '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" stroke-width="1.5"/><circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/><path d="M21 15l-5-5-6 6-3-3-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

const TEMPLATE = document.createElement("template");
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: none;
      font-family: var(--font-family-base);
    }
    :host([open]) {
      display: flex;
      position: fixed;
      inset: 0;
      align-items: center;
      justify-content: center;
      padding: var(--space-4);
      background: var(--color-overlay-modal);
      z-index: 1000;
      box-sizing: border-box;
    }
    .dialog {
      display: flex;
      flex-direction: column;
      width: min(92vw, 760px);
      max-height: 88vh;
      background: var(--color-bg-primary);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-modal);
      overflow: hidden;
    }
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: var(--space-3);
      padding: var(--space-4);
      border-bottom: 1px solid var(--color-border-default);
    }
    .header h2 {
      margin: 0;
      font-size: var(--font-size-h4);
      line-height: var(--line-height-h4);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
    }
    .body {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 400px;
      background: var(--color-bg-secondary);
      color: var(--color-text-disabled);
    }
    .body img {
      max-width: 100%;
      max-height: 70vh;
      display: block;
    }
  </style>
  <div class="dialog" role="dialog" aria-modal="true">
    <div class="header">
      <h2 class="title"></h2>
      <ares-icon-button class="btn-close" variant="neutral" label="Cerrar">${CLOSE_ICON}</ares-icon-button>
    </div>
    <div class="body"></div>
  </div>
`;

class AresEvidenceModal extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._data = null;
    this._els = {
      title: this.shadowRoot.querySelector(".title"),
      body: this.shadowRoot.querySelector(".body"),
      btnClose: this.shadowRoot.querySelector(".btn-close"),
    };
    this._els.btnClose.addEventListener("click", () => {
      this.dispatchEvent(
        new CustomEvent("ares-cancel", { bubbles: true, composed: true }),
      );
    });
    this._upgradeProperty("data");
  }

  // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
  _upgradeProperty(prop) {
    if (Object.prototype.hasOwnProperty.call(this, prop)) {
      const value = this[prop];
      delete this[prop];
      this[prop] = value;
    }
  }

  /** @param {import('../types.js').EvidenceModalData} value */
  set data(value) {
    this._data = value;
    this._render();
  }

  get data() {
    return this._data;
  }

  _render() {
    const d = this._data;
    if (!d) return;
    this._els.title.textContent = `Evidencia · ${d.alarmaId}`;
    this._els.body.innerHTML = "";
    if (d.imagenUrl) {
      const img = document.createElement("img");
      img.src = d.imagenUrl;
      img.alt = `Evidencia de ${d.alarmaId}`;
      this._els.body.appendChild(img);
    } else {
      this._els.body.innerHTML = PLACEHOLDER_ICON;
    }
  }
}

if (!customElements.get("ares-evidence-modal")) {
  customElements.define("ares-evidence-modal", AresEvidenceModal);
}
})();
