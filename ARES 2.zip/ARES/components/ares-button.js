(function () {
'use strict';

/**
 * <ares-button>
 *
 * Botón reusado como Aprobar/Gestionar/Tomar INC (intent="primary"),
 * Detalles/Cancelar/Volver (intent="secondary", default) y Rechazar
 * (intent="destructive").
 *
 * Atributos:
 *   intent    "primary" | "secondary" (default) | "destructive"
 *   tone      solo con intent="primary": "brand" (default) | "success"
 *   disabled  boolean nativo. No aplica a intent="primary" (Aprobar/
 *             Gestionar/Tomar INC siempre son accionables).
 *
 * Slots:
 *   (default)     texto del botón
 *   icon-start    ícono antes del texto
 *   icon-end      ícono después del texto
 */

const TEMPLATE = document.createElement("template");
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      font-family: var(--font-family-base);
    }

    button {
      all: unset;
      box-sizing: border-box;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: var(--space-2);
      cursor: pointer;
      font-family: var(--font-family-base);
      font-weight: var(--font-weight-bold);
      border-radius: var(--radius-md);
      white-space: nowrap;
    }

    button:disabled {
      cursor: not-allowed;
    }

    ::slotted([slot="icon-start"]),
    ::slotted([slot="icon-end"]) {
      display: inline-flex;
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }

    /* ---- secondary (default) ---- */
    :host(:not([intent])) button,
    :host([intent="secondary"]) button {
      background: var(--color-bg-primary);
      border: 1px solid var(--color-border-default);
      color: var(--color-text-secondary);
      padding: var(--space-2) var(--space-3);
      font-size: var(--font-size-sm);
      line-height: var(--line-height-sm);
      font-weight: var(--font-weight-regular);
    }
    :host(:not([intent])) button:hover,
    :host([intent="secondary"]) button:hover {
      background: var(--color-bg-tertiary);
    }
    :host(:not([intent])) button:active,
    :host([intent="secondary"]) button:active {
      background: var(--color-bg-quaternary);
    }
    :host(:not([intent])) button:disabled,
    :host([intent="secondary"]) button:disabled {
      background: var(--color-bg-primary);
      border-color: var(--color-border-default);
      color: var(--color-text-disabled);
    }

    /* ---- primary / tone="brand" (default tone) ---- */
    :host([intent="primary"]) button,
    :host([intent="primary"][tone="brand"]) button {
      background: var(--color-bg-brand);
      color: var(--color-text-secondary);
      padding: var(--space-2) var(--space-3);
      font-size: var(--font-size-sm);
      line-height: var(--line-height-sm);
    }
    :host([intent="primary"]) button:hover,
    :host([intent="primary"][tone="brand"]) button:hover {
      background: var(--color-interactive-primary-hover);
    }
    :host([intent="primary"]) button:active,
    :host([intent="primary"][tone="brand"]) button:active {
      background: var(--color-bg-brand-strong);
    }
    /* ---- primary / tone="success" ---- */
    :host([intent="primary"][tone="success"]) button {
      background: var(--color-interactive-success);
      color: var(--color-text-inverse);
      padding: var(--space-3);
      font-size: var(--font-size-base);
      line-height: var(--line-height-base);
    }
    :host([intent="primary"][tone="success"]) button:hover {
      background: var(--color-interactive-success-hover);
    }
    :host([intent="primary"][tone="success"]) button:active {
      background: var(--color-interactive-success-pressed);
    }
    /* ---- destructive ---- */
    :host([intent="destructive"]) button {
      background: var(--color-interactive-danger);
      color: var(--color-text-inverse);
      padding: var(--space-3);
      font-size: var(--font-size-sm);
      line-height: var(--line-height-sm);
    }
    :host([intent="destructive"]) button:hover {
      background: var(--color-interactive-danger-hover);
    }
    :host([intent="destructive"]) button:active {
      background: var(--color-interactive-danger-pressed);
    }
    :host([intent="destructive"]) button:disabled {
      background: var(--color-bg-quaternary);
      color: var(--color-text-disabled);
    }
  </style>
  <button type="button" part="button">
    <slot name="icon-start"></slot>
    <slot></slot>
    <slot name="icon-end"></slot>
  </button>
`;

class AresButton extends HTMLElement {
  static get observedAttributes() {
    return ["disabled", "intent"];
  }

  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._button = this.shadowRoot.querySelector("button");
  }

  connectedCallback() {
    this._syncDisabled();
  }

  attributeChangedCallback() {
    this._syncDisabled();
  }

  _syncDisabled() {
    // intent="primary" siempre es accionable: el atributo disabled se ignora.
    const isPrimary = this.getAttribute("intent") === "primary";
    this._button.disabled = !isPrimary && this.hasAttribute("disabled");
  }
}

if (!customElements.get("ares-button")) {
  customElements.define("ares-button", AresButton);
}
})();
