(function () {
'use strict';

/**
 * <ares-problema-tag>
 *
 * Tag de tipo de incidente.
 *
 * Atributo:
 *   tipo   "pon-loss" | "cto-indisponible" | "gasp"
 */

const LABELS = {
  'pon-loss': 'PON Loss',
  'cto-indisponible': 'CTO Indisponible',
  gasp: 'Dying gasp',
};

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      font-family: var(--font-family-base);
    }

    .tag {
      display: inline-flex;
      align-items: center;
      padding: var(--space-1) var(--space-2);
      border: 1px solid;
      border-radius: var(--radius-md);
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
      font-weight: var(--font-weight-regular);
      white-space: nowrap;
    }

    :host([tipo="pon-loss"]) .tag,
    :host(:not([tipo])) .tag {
      background: var(--color-bg-error);
      border-color: var(--color-border-error);
      color: var(--color-text-error);
    }

    :host([tipo="cto-indisponible"]) .tag {
      background: var(--color-bg-warning);
      border-color: var(--color-border-warning);
      color: var(--color-text-warning);
    }

    :host([tipo="gasp"]) .tag {
      background: var(--color-bg-info);
      border-color: var(--color-interactive-secondary);
      color: var(--color-text-info);
    }
  </style>
  <span class="tag"></span>
`;

class AresProblemaTag extends HTMLElement {
  static get observedAttributes() {
    return ['tipo'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._tag = this.shadowRoot.querySelector('.tag');
  }

  connectedCallback() {
    this._sync();
  }

  attributeChangedCallback() {
    this._sync();
  }

  _sync() {
    this._tag.textContent = LABELS[this.getAttribute('tipo')] || LABELS['pon-loss'];
  }
}

if (!customElements.get('ares-problema-tag')) {
  customElements.define('ares-problema-tag', AresProblemaTag);
}
})();
