(function () {
'use strict';

/**
 * <ares-icon-button>
 *
 * Botón de solo ícono: variant="neutral" (cerrar/volver), "brand" (abrir
 * imagen), "search" (barra de búsqueda).
 *
 * Atributos:
 *   variant   "neutral" (default) | "brand" | "search"
 *   label     texto accesible (aria-label) — obligatorio
 *   disabled  boolean nativo
 *   tooltip   texto opcional — tooltip flotante en hover/focus, oculto si
 *             está disabled
 *
 * Slots:
 *   (default)  ícono (SVG inline, no <img>, para heredar color vía currentColor)
 *   text       solo variant="search": texto del placeholder
 */

const TEMPLATE = document.createElement("template");
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      position: relative;
      font-family: var(--font-family-base);
    }

    .tooltip {
      display: none;
      position: absolute;
      left: 50%;
      top: calc(100% + var(--space-1));
      transform: translateX(-50%);
      padding: var(--space-1) var(--space-2);
      border-radius: var(--radius-sm);
      background: var(--color-bg-inverse);
      color: var(--color-text-inverse);
      font-size: var(--font-size-caption);
      line-height: var(--line-height-caption);
      white-space: nowrap;
      box-shadow: var(--shadow-tooltip);
      z-index: 10;
      pointer-events: none;
    }
    :host([tooltip]:hover) .tooltip,
    :host([tooltip]:focus-within) .tooltip {
      display: block;
    }
    :host([disabled]) .tooltip {
      display: none !important;
    }

    button {
      all: unset;
      box-sizing: border-box;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }

    button:disabled {
      cursor: not-allowed;
    }

    ::slotted(:not([slot="text"])) {
      display: inline-flex;
      flex-shrink: 0;
    }

    /* ---- neutral (default) ---- */
    :host(:not([variant])) button,
    :host([variant="neutral"]) button {
      width: 30px;
      height: 30px;
      background: var(--color-bg-primary);
      border: 1px solid var(--color-border-default);
      border-radius: var(--radius-md);
    }
    :host(:not([variant])) button ::slotted(*),
    :host([variant="neutral"]) button ::slotted(*) {
      width: 16px;
      height: 16px;
      color: var(--color-icon-disabled);
    }
    :host(:not([variant])) button:hover,
    :host([variant="neutral"]) button:hover {
      background: var(--color-bg-tertiary);
    }
    :host(:not([variant])) button:active,
    :host([variant="neutral"]) button:active {
      background: var(--color-bg-quaternary);
    }
    :host(:not([variant])) button:disabled,
    :host([variant="neutral"]) button:disabled {
      background: var(--color-bg-primary);
      border-color: var(--color-border-default);
    }
    :host(:not([variant])) button:disabled ::slotted(*),
    :host([variant="neutral"]) button:disabled ::slotted(*) {
      opacity: 0.5;
    }

    /* ---- brand ---- */
    :host([variant="brand"]) button {
      padding: var(--space-1);
      background: var(--color-bg-brand);
      border-radius: var(--radius-sm);
      box-shadow: var(--shadow-xs-brand);
    }
    :host([variant="brand"]) button ::slotted(*) {
      width: 20px;
      height: 20px;
      color: var(--color-text-inverse);
    }
    :host([variant="brand"]) button:hover {
      background: var(--color-interactive-primary-hover);
      box-shadow: var(--shadow-xs-brand-hover);
    }
    :host([variant="brand"]) button:active {
      background: var(--color-bg-brand-strong);
    }
    :host([variant="brand"]) button:disabled {
      background: var(--color-bg-secondary);
      border: 1px solid var(--color-border-strong);
      box-shadow: none;
    }
    :host([variant="brand"]) button:disabled ::slotted(*) {
      color: var(--color-icon-disabled);
      opacity: 0.6;
    }

    /* ---- search ---- */
    :host([variant="search"]) {
      width: 100%;
    }
    :host([variant="search"]) button {
      width: 100%;
      gap: var(--space-2);
      padding: var(--space-2);
      background: var(--color-bg-primary);
      border: 1px solid var(--color-border-default);
      border-radius: var(--radius-md);
      justify-content: flex-start;
    }
    :host([variant="search"]) button ::slotted(:not([slot="text"])) {
      width: 14px;
      height: 14px;
    }
    ::slotted([slot="text"]) {
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
      color: var(--color-text-tertiary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    :host([variant="search"]) button:hover {
      background: var(--color-bg-tertiary);
    }
    :host([variant="search"]) button:active {
      background: var(--color-bg-quaternary);
    }
  </style>
  <button type="button" part="button">
    <slot></slot>
    <slot name="text"></slot>
  </button>
  <div class="tooltip"></div>
`;

class AresIconButton extends HTMLElement {
  static get observedAttributes() {
    return ["disabled", "label", "tooltip"];
  }

  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._button = this.shadowRoot.querySelector("button");
    this._tooltip = this.shadowRoot.querySelector(".tooltip");
  }

  connectedCallback() {
    this._sync();
  }

  attributeChangedCallback() {
    this._sync();
  }

  _sync() {
    this._button.disabled = this.hasAttribute("disabled");
    const label = this.getAttribute("label");
    if (label) {
      this._button.setAttribute("aria-label", label);
    } else {
      this._button.removeAttribute("aria-label");
    }
    this._tooltip.textContent = this.getAttribute("tooltip") || "";
  }
}

if (!customElements.get("ares-icon-button")) {
  customElements.define("ares-icon-button", AresIconButton);
}
})();
