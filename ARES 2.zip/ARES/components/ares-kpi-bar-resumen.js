(function () {
'use strict';

/**
 * <ares-kpi-bar-resumen>
 *
 * Tarjeta simple título+valor del header de bandeja ("Afectación total",
 * "Total alarmas", "Inc con más de 24 horas", "Inc en terreno").
 *
 * Atributos:
 *   titulo   texto del título, ej. "Afectación total"
 *   valor    texto del valor, ej. "1.984 Afectados" (DATA-INPUT)
 */

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      font-family: var(--font-family-base);
    }
    .card {
      display: flex;
      flex-direction: column;
      gap: var(--space-2);
      align-items: flex-start;
      padding: var(--space-2) var(--space-6);
      border-radius: var(--radius-md);
      background: var(--color-bg-primary);
      box-sizing: border-box;
    }
    :host(:hover) .card {
      background: var(--color-bg-quaternary);
    }
    .titulo {
      font-size: var(--font-size-base);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
      white-space: nowrap;
    }
    .valor {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-regular);
      color: var(--color-text-secondary);
      white-space: nowrap;
    }
  </style>
  <div class="card">
    <span class="titulo"></span>
    <span class="valor"></span>
  </div>
`;

class AresKpiBarResumen extends HTMLElement {
  static get observedAttributes() {
    return ['titulo', 'valor'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._titulo = this.shadowRoot.querySelector('.titulo');
    this._valor = this.shadowRoot.querySelector('.valor');
  }

  connectedCallback() {
    this._sync();
  }

  attributeChangedCallback() {
    this._sync();
  }

  _sync() {
    this._titulo.textContent = this.getAttribute('titulo') || '';
    this._valor.textContent = this.getAttribute('valor') || '';
  }
}

if (!customElements.get('ares-kpi-bar-resumen')) {
  customElements.define('ares-kpi-bar-resumen', AresKpiBarResumen);
}
})();
