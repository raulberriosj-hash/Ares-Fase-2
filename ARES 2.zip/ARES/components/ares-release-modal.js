(function () {
'use strict';

/**
 * <ares-release-modal>
 *
 * Modal de confirmación al liberar una incidencia tomada.
 *
 * Atributo:
 *   open   boolean — controla visibilidad
 *
 * Tipo de dato: ReleaseModalData (ver types.js).
 *
 * Eventos:
 *   ares-cancel    click en "Cancelar" o en el ícono de cierre
 *   ares-liberar   click en "Liberar". detail: { id }
 */

const CLOSE_ICON =
  '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.33333"/></svg>';

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: none;
      font-family: var(--font-family-base);
    }
    :host([open]) {
      display: flex;
      position: fixed;
      inset: 0;
      align-items: center;
      justify-content: center;
      padding: var(--space-4);
      background: var(--color-overlay-modal);
      z-index: 1000;
      box-sizing: border-box;
    }
    .dialog {
      display: flex;
      flex-direction: column;
      width: min(94vw, 1040px);
      max-height: 88vh;
      overflow: auto;
      background: var(--color-bg-primary);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-modal);
    }
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: var(--space-3);
      padding: var(--space-6);
      border-bottom: 1px solid var(--color-border-default);
    }
    .header h2 {
      margin: 0;
      font-size: var(--font-size-h3);
      line-height: var(--line-height-h3);
      letter-spacing: var(--letter-spacing-h3);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
    }
    .body {
      display: flex;
      flex-direction: column;
      gap: var(--space-6);
      padding: var(--space-6);
      background: var(--color-bg-tertiary);
    }
    .body p {
      margin: 0;
      font-size: var(--font-size-base);
      line-height: var(--line-height-base);
      color: var(--color-text-primary);
    }
    .actions {
      display: flex;
      justify-content: flex-end;
      gap: var(--space-2);
    }
  </style>
  <div class="dialog" role="dialog" aria-modal="true">
    <div class="header">
      <h2>Liberar Incidencia</h2>
      <ares-icon-button class="btn-close" variant="neutral" label="Cerrar">${CLOSE_ICON}</ares-icon-button>
    </div>
    <div class="body">
      <p>Al liberar la gestión de este incidente, este volverá al estado "Pendiente" y quedará disponible para que otra persona pueda tomarlo.</p>
      <ares-incident-row class="summary" compacta variante="en-curso"></ares-incident-row>
      <div class="actions">
        <ares-button class="btn-cancel">Cancelar</ares-button>
        <ares-button class="btn-liberar" intent="primary">Liberar</ares-button>
      </div>
    </div>
  </div>
`;

class AresReleaseModal extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._data = null;
    this._els = {
      summary: this.shadowRoot.querySelector('.summary'),
      btnClose: this.shadowRoot.querySelector('.btn-close'),
      btnCancel: this.shadowRoot.querySelector('.btn-cancel'),
      btnLiberar: this.shadowRoot.querySelector('.btn-liberar'),
    };
    const cancel = () => this.dispatchEvent(new CustomEvent('ares-cancel', { bubbles: true, composed: true }));
    this._els.btnClose.addEventListener('click', cancel);
    this._els.btnCancel.addEventListener('click', cancel);
    this._els.btnLiberar.addEventListener('click', () => {
      this.dispatchEvent(
        new CustomEvent('ares-liberar', { detail: { id: this._data?.incidencia?.id }, bubbles: true, composed: true })
      );
    });
    this._upgradeProperty('data');
  }

  // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
  _upgradeProperty(prop) {
    if (Object.prototype.hasOwnProperty.call(this, prop)) {
      const value = this[prop];
      delete this[prop];
      this[prop] = value;
    }
  }

  /** @param {import('../types.js').ReleaseModalData} value */
  set data(value) {
    this._data = value;
    this._render();
  }

  get data() {
    return this._data;
  }

  _render() {
    const d = this._data;
    if (!d) return;
    // Fase 2: <ares-incident-row> compacto (espera IncidentRowData).
    this._els.summary.data = {
      incidencia: d.incidencia,
      responsable: d.incidencia.responsable,
      esPropia: true, // solo se libera la incidencia propia
    };
  }
}

if (!customElements.get('ares-release-modal')) {
  customElements.define('ares-release-modal', AresReleaseModal);
}
})();
