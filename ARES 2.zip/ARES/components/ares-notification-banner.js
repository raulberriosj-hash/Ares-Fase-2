(function () {
  'use strict';

  /**
   * <ares-notification-banner>
   *
   * Banner informativo del resultado de la gestión, sobre el contenido de la
   * pantalla de detalle. Aparece exactamente cuando la barra de acción
   * desaparece: en los estados terminales del flujo, y en el paso intermedio
   * "evidencia aprobada, correlación pendiente".
   *
   * Nuevo en Fase 2 (ver DIFF-FASE2.md, N5 — `notifications`, 2117:5776).
   *
   * Atributo:
   *   tipo   "evidencia-aprobada" | "evidencia-rechazada" |
   *          "correlacion-aprobada" | "correlacion-rechazada" |
   *          "evidencia-aprobada-correlacion-pendiente"
   *
   * La copy va fija en el componente (mismo patrón que ares-tooltip-flag):
   * son 5 textos cerrados definidos por diseño, no contenido variable. Lo
   * único DATA-INPUT es *cuál* de los 5 corresponde mostrar, que lo decide
   * el estado de la incidencia.
   *
   * Decisión de naming (ver DIFF-FASE2.md, P11): en Figma la variante verde
   * de evidencia se llama "Incidencia Aprobada", pero su propio texto habla
   * de la evidencia, y el badge de estado equivalente se llama "Evidencia
   * Aprobada". Se usa `evidencia-aprobada` para que ambos componentes
   * hablen el mismo idioma. Queda pendiente que diseño unifique el nombre
   * en Figma.
   */

  const COPY = {
    'evidencia-aprobada': {
      titulo: 'Evidencia Aprobada',
      descripcion:
        'La evidencia de esta Incidencia fue aprobada por un especialista y ha sido actualizada en ServiceNow.',
    },
    'evidencia-rechazada': {
      titulo: 'Evidencia Rechazada',
      descripcion:
        'La evidencia de esta Incidencia fue rechazada por un especialista, por lo que ahora deberá ser gestionada internamente a través de ServiceNow.',
    },
    'correlacion-aprobada': {
      titulo: 'Correlación Aprobada',
      descripcion:
        'La correlación de Incidencias fue aprobada por un especialista y ha sido actualizada en ServiceNow.',
    },
    'correlacion-rechazada': {
      titulo: 'Correlación Rechazada',
      descripcion:
        'La correlación de Incidencias fue rechazada por un especialista, por lo que ahora deberá ser gestionada internamente a través de ServiceNow.',
    },
    'evidencia-aprobada-correlacion-pendiente': {
      titulo: 'Evidencia Aprobada · Correlación Pendiente',
      descripcion:
        'La evidencia de esta incidencia fue aprobada por un especialista y ya fue actualizada en ServiceNow. Ahora debes aprobar o rechazar la correlación de incidencias.',
    },
  };

  /* Ícono "i" en círculo. Construido sobre la misma geometría que
     icons/ic-error.svg para que calce con la familia de íconos del
     proyecto (mismo círculo, glifo invertido).
     DISEÑO-PENDIENTE menor: falta exportar el asset definitivo desde Figma
     (el frame usa un ícono propio, todavía sin nombre en la sección icons). */
  const INFO_ICON = `
    <svg class="icono" width="20" height="20" viewBox="0 0 20 20" fill="none"
         xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M11 7H9V5H11V7ZM10 9C10.55 9 11 9.45 11 10V14C11 14.55 10.55 15 10 15C9.45 15 9 14.55 9 14V10C9 9.45 9.45 9 10 9ZM9.99 0C4.47 0 0 4.48 0 10C0 15.52 4.47 20 9.99 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 9.99 0ZM10 18C5.58 18 2 14.42 2 10C2 5.58 5.58 2 10 2C14.42 2 18 5.58 18 10C18 14.42 14.42 18 10 18Z"
            fill="currentColor"/>
    </svg>`;

  const TEMPLATE = document.createElement('template');
  TEMPLATE.innerHTML = `
  <style>
    :host {
      display: block;
      font-family: var(--font-family-base);
    }

    /* Sin tipo válido no se renderiza nada, en vez de una caja vacía. */
    :host(:not([tipo])) .banner { display: none; }

    .banner {
      padding: var(--space-3) var(--space-4);
      border: 1px solid;
      border-radius: var(--radius-md);
    }

    .head {
      display: flex;
      align-items: center;
      gap: var(--space-2);
    }

    .icono { flex-shrink: 0; }

    .titulo {
      font-size: var(--font-size-sm);
      line-height: var(--line-height-sm);
      font-weight: var(--font-weight-bold);
    }

    .descripcion {
      margin: var(--space-1) 0 0;
      font-size: var(--font-size-sm);
      line-height: var(--line-height-sm);
      color: var(--color-text-secondary);
    }

    /* verde — cualquier etapa aprobada */
    :host([tipo="evidencia-aprobada"]) .banner,
    :host([tipo="correlacion-aprobada"]) .banner {
      background: var(--color-bg-success);
      border-color: var(--color-border-success);
    }
    :host([tipo="evidencia-aprobada"]) .head,
    :host([tipo="correlacion-aprobada"]) .head {
      color: var(--color-text-success);
    }

    /* rojo — cualquier etapa rechazada */
    :host([tipo="evidencia-rechazada"]) .banner,
    :host([tipo="correlacion-rechazada"]) .banner {
      background: var(--color-bg-error);
      border-color: var(--color-border-error);
    }
    :host([tipo="evidencia-rechazada"]) .head,
    :host([tipo="correlacion-rechazada"]) .head {
      color: var(--color-text-error);
    }

    /* morado — paso intermedio, todavía requiere acción del usuario */
    :host([tipo="evidencia-aprobada-correlacion-pendiente"]) .banner {
      background: var(--color-bg-info);
      border-color: var(--color-border-info);
    }
    :host([tipo="evidencia-aprobada-correlacion-pendiente"]) .head {
      color: var(--color-text-info);
    }
  </style>
  <div class="banner" role="status">
    <div class="head">
      ${INFO_ICON}
      <span class="titulo"></span>
    </div>
    <p class="descripcion"></p>
  </div>
`;

  class AresNotificationBanner extends HTMLElement {
    static get observedAttributes() {
      return ['tipo'];
    }

    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
      this._titulo = this.shadowRoot.querySelector('.titulo');
      this._descripcion = this.shadowRoot.querySelector('.descripcion');
    }

    connectedCallback() {
      this._sync();
    }

    attributeChangedCallback() {
      this._sync();
    }

    _sync() {
      const copy = COPY[this.getAttribute('tipo')];
      this._titulo.textContent = copy ? copy.titulo : '';
      this._descripcion.textContent = copy ? copy.descripcion : '';
    }
  }

  if (!customElements.get('ares-notification-banner')) {
    customElements.define('ares-notification-banner', AresNotificationBanner);
  }
})();
