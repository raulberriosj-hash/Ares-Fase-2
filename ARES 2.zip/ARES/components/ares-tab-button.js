(function () {
'use strict';

/**
 * <ares-tab-button>
 *
 * Tab de la bandeja (Pendientes / En Curso / Histórico).
 *
 * Atributos:
 *   active    boolean — tab actualmente seleccionado
 *   count     número/string opcional — muestra el badge contador
 *
 * Slots:
 *   icon        ícono del tab (SVG inline con fill="currentColor", no <img>)
 *   (default)   texto del tab
 */

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      font-family: var(--font-family-base);
    }

    button {
      all: unset;
      box-sizing: border-box;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: var(--space-2);
      cursor: pointer;
      padding: var(--space-3);
      border-bottom: 2px solid var(--color-border-default);
      border-radius: var(--radius-sm) var(--radius-sm) 0 0;
      background: var(--color-bg-primary);
      color: var(--color-text-tertiary);
      font-size: var(--font-size-sm);
      line-height: var(--line-height-sm);
      font-weight: var(--font-weight-regular);
    }

    ::slotted([slot="icon"]) {
      display: inline-flex;
      width: 20px;
      height: 20px;
      flex-shrink: 0;
      color: var(--color-text-tertiary);
    }

    .badge {
      display: none;
      align-items: center;
      padding: var(--space-1) var(--space-2);
      border: 1px solid var(--color-border-default);
      border-radius: var(--radius-pill);
      background: var(--color-bg-primary);
      color: var(--color-text-tertiary);
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      line-height: var(--line-height-xs);
    }
    :host([count]) .badge {
      display: inline-flex;
    }

    button:hover {
      background: var(--color-bg-secondary);
      color: var(--color-text-tertiary);
      font-weight: var(--font-weight-bold);
    }
    button:hover ::slotted([slot="icon"]) {
      color: var(--color-text-tertiary);
    }

    button:active {
      background: var(--color-border-strong);
      border-bottom-color: var(--color-text-tertiary);
      color: var(--color-text-secondary);
      font-weight: var(--font-weight-bold);
    }
    button:active ::slotted([slot="icon"]) {
      color: var(--color-text-secondary);
    }

    button:focus-visible {
      background: var(--color-bg-primary);
      border-bottom-color: var(--color-border-brand);
      color: var(--color-text-primary);
      font-weight: var(--font-weight-bold);
      outline: none;
    }
    button:focus-visible ::slotted([slot="icon"]) {
      color: var(--color-text-primary);
    }

    :host([active]) button {
      background: var(--color-bg-primary);
      border-bottom-color: var(--color-border-brand);
      color: var(--color-text-brand);
      font-weight: var(--font-weight-bold);
    }
    :host([active]) button ::slotted([slot="icon"]) {
      color: var(--color-text-brand);
    }
    :host([active]) .badge {
      color: var(--color-text-brand);
    }
  </style>
  <button type="button" part="button" role="tab">
    <slot name="icon"></slot>
    <slot></slot>
    <span class="badge"><slot name="count-text"></slot></span>
  </button>
`;

class AresTabButton extends HTMLElement {
  static get observedAttributes() {
    return ['active', 'count'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._button = this.shadowRoot.querySelector('button');
    this._badgeText = this.shadowRoot.querySelector('slot[name="count-text"]');
  }

  connectedCallback() {
    this._sync();
  }

  attributeChangedCallback() {
    this._sync();
  }

  _sync() {
    this._button.setAttribute('aria-selected', this.hasAttribute('active') ? 'true' : 'false');
    const count = this.getAttribute('count');
    if (count !== null) {
      this._badgeText.textContent = count;
    }
  }
}

if (!customElements.get('ares-tab-button')) {
  customElements.define('ares-tab-button', AresTabButton);
}
})();
