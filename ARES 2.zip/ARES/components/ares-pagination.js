(function () {
  'use strict';

  /**
   * <ares-pagination>
   *
   * Control de paginación: etiqueta "Página X de Y" a la izquierda y los
   * controles numéricos a la derecha.
   *
   * Nota de origen: NO es un componente del archivo de Figma — es una
   * extracción. La lógica y los estilos venían duplicados a mano en
   * gestion-incidencia.js/.html (tabla de alarmas). En Fase 2 el mismo
   * control aparece en 4 lugares (bandeja, alarmas, incidencias
   * correlacionadas, y anidado dentro de la fila expandida), así que se
   * saca a componente en vez de copiarlo 4 veces. El comportamiento y el
   * aspecto se preservan exactamente: misma ventana de páginas visibles,
   * mismos estilos.
   *
   * Atributos:
   *   pagina          página actual (1-based). Default 1.
   *   total-paginas   total de páginas. Default 1.
   *
   * Evento:
   *   ares-cambio-pagina   detail: { pagina }
   *
   * El componente NO cambia de página por su cuenta: emite el evento y
   * espera que el consumidor le devuelva el atributo `pagina` actualizado
   * (controlled component). Así el estado vive en un solo lugar.
   */

  const TEMPLATE = document.createElement('template');
  TEMPLATE.innerHTML = `
  <style>
    :host {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: var(--space-3);
      font-family: var(--font-family-base);
    }

    /* Una sola página: no tiene sentido mostrar controles. */
    :host([total-paginas="1"]) .controls { display: none; }

    .label {
      font-size: var(--font-size-xs);
      color: var(--color-text-tertiary);
    }

    .controls {
      display: flex;
      align-items: center;
      gap: var(--space-1);
    }

    .page-btn {
      all: unset;
      cursor: pointer;
      min-width: 28px;
      height: 28px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: var(--radius-sm);
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-secondary);
    }
    .page-btn[aria-current="true"] {
      background: var(--color-bg-brand);
      color: var(--color-text-inverse);
    }
    .page-btn:disabled {
      color: var(--color-text-disabled);
      cursor: not-allowed;
    }
    .page-btn:focus-visible {
      outline: 2px solid var(--color-border-focus);
      outline-offset: 1px;
    }
    .page-dots {
      padding: 0 var(--space-1);
      font-size: var(--font-size-xs);
      color: var(--color-text-tertiary);
    }
  </style>
  <span class="label"></span>
  <nav class="controls" aria-label="Paginación"></nav>
`;

  class AresPagination extends HTMLElement {
    static get observedAttributes() {
      return ['pagina', 'total-paginas'];
    }

    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
      this._label = this.shadowRoot.querySelector('.label');
      this._controls = this.shadowRoot.querySelector('.controls');
      this._upgradeProperty('pagina');
      this._upgradeProperty('totalPaginas');
    }

    // Recupera la propiedad si se asignó antes de que el elemento hiciera upgrade.
    _upgradeProperty(prop) {
      if (Object.prototype.hasOwnProperty.call(this, prop)) {
        const value = this[prop];
        delete this[prop];
        this[prop] = value;
      }
    }

    set pagina(v) {
      this.setAttribute('pagina', v);
    }

    get pagina() {
      // Se acota al rango válido para que un valor fuera de rango no rompa el render.
      const total = this.totalPaginas;
      const p = Number(this.getAttribute('pagina')) || 1;
      return Math.min(Math.max(p, 1), total);
    }

    set totalPaginas(v) {
      this.setAttribute('total-paginas', v);
    }

    get totalPaginas() {
      return Math.max(1, Number(this.getAttribute('total-paginas')) || 1);
    }

    connectedCallback() {
      this._render();
    }

    attributeChangedCallback() {
      this._render();
    }

    _emitir(pagina) {
      this.dispatchEvent(
        new CustomEvent('ares-cambio-pagina', {
          detail: { pagina },
          bubbles: true,
          composed: true,
        })
      );
    }

    _boton({ texto, destino, disabled, actual, aria }) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'page-btn';
      btn.textContent = texto;
      if (disabled) btn.disabled = true;
      if (actual !== undefined) btn.setAttribute('aria-current', String(actual));
      if (aria) btn.setAttribute('aria-label', aria);
      btn.addEventListener('click', () => this._emitir(destino));
      return btn;
    }

    _render() {
      const pagina = this.pagina;
      const total = this.totalPaginas;

      this._label.textContent = `Página ${pagina} de ${total}`;
      this._controls.innerHTML = '';

      this._controls.appendChild(
        this._boton({
          texto: '‹',
          destino: pagina - 1,
          disabled: pagina === 1,
          aria: 'Página anterior',
        })
      );

      /* Misma ventana que usaba gestion-incidencia.js: primera, última,
         actual y sus vecinas; el resto se colapsa en "…". */
      const aMostrar = new Set([1, total, pagina, pagina - 1, pagina + 1]);
      let ultimo = 0;
      Array.from(aMostrar)
        .filter((p) => p >= 1 && p <= total)
        .sort((a, b) => a - b)
        .forEach((p) => {
          if (ultimo && p - ultimo > 1) {
            const dots = document.createElement('span');
            dots.className = 'page-dots';
            dots.textContent = '…';
            this._controls.appendChild(dots);
          }
          this._controls.appendChild(
            this._boton({
              texto: String(p),
              destino: p,
              actual: p === pagina,
              aria: `Página ${p}`,
            })
          );
          ultimo = p;
        });

      this._controls.appendChild(
        this._boton({
          texto: '›',
          destino: pagina + 1,
          disabled: pagina === total,
          aria: 'Página siguiente',
        })
      );
    }
  }

  if (!customElements.get('ares-pagination')) {
    customElements.define('ares-pagination', AresPagination);
  }
})();
