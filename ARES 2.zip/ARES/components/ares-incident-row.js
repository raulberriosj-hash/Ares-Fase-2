(function () {
'use strict';

/**
 * <ares-incident-row>
 *
 * Fila completa de incidencia en la bandeja.
 *   - pendiente:  SIN responsable. Botones: Detalles + Tomar INC.
 *   - en-curso / historico:  CON responsable. Botón: Detalles únicamente.
 *
 * Fase 2 (ver DIFF-FASE2.md, M3). Layout tomado de la metadata real de Figma
 * (tabla/row_desplegable_consolidacion_pendiente 2030:4992 y
 * tabla/row_individual_pendiente 2072:3769 — ambos comparten exactamente la
 * misma grilla, por eso un solo componente cubre los dos casos):
 *
 *   ancho 1212 · alto 78 · padding lateral 25 · gap 24
 *   5 columnas IGUALES de 171.6px + columna de botones fija de 184px
 *   25 + (171.6 × 5) + (24 × 5) + 184 + 25 = 1212 ✓
 *
 *   1. ID + agrupación   2. tipo + estado   3. fechas
 *   4. afectación/alarmas   5. OLT   6. botones
 *
 * Toda la card es el área interactiva: hover, pressed y el despliegue de las
 * hijas responden al click en cualquier parte, no solo en el chevron (así
 * está definido en Figma). Los botones internos detienen la propagación.
 *
 * Colores de estado muestreados del propio Figma:
 *   fila     default #FFFFFF · hover #F1F7F9 · pressed #E3EBEF
 *   borde    #CCDAE0 en todos los estados
 *   hijas    fondo #F1F7F9
 *
 * Se compone de átomos existentes:
 *   <ares-expand-button> <ares-count-badge> <ares-problema-tag>
 *   <ares-status-badge> <ares-button> <ares-correlated-row> <ares-pagination>
 *
 * Atributos:
 *   variante    "pendiente" | "en-curso" | "historico"
 *   expandido   booleano — muestra el bloque de incidencias hijas
 *   compacta    booleano — oculta botones y responsable. Se usa cuando la
 *               fila va dentro de un modal, donde solo ilustra de qué
 *               incidencia se habla y las acciones las da el modal.
 *
 * Tipo de dato: IncidentRowData (ver types.js).
 *
 * Eventos:
 *   ares-tomar-inc        detail: { id }
 *   ares-detalles         detail: { id }
 *   ares-toggle-expandir  detail: { id, expandido }
 *   ares-detalles-hija    detail: { id, padreId }
 */

/* Hijas por página dentro de la fila expandida. El mock de Figma muestra 5
   filas con "Página 1 de 6", un total que no cuadra con el badge del padre
   (ver DIFF-FASE2.md, P6/P15): acá el total se calcula de hijas.length. */
const HIJAS_POR_PAGINA = 5;

const ICON_AFECTACION =
  '<svg width="21" height="21" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.6"/><path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';

const ICON_ALARMAS =
  '<svg width="21" height="21" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4 2.5 20h19L12 4Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 10v4M12 17h.01" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: block;
      font-family: var(--font-family-base);
    }

    .fila {
      background: var(--color-bg-primary);
      border: 1px solid var(--color-border-strong);
      border-radius: var(--radius-lg);
      overflow: hidden;
    }

    .main {
      display: flex;
      align-items: center;
      gap: 24px;
      min-height: 78px;
      padding: 0 25px;
      box-sizing: border-box;
    }

    /* Toda la card es clickeable solo si hay hijas que desplegar. */
    :host([agrupacion="consolidacion"]) .main { cursor: pointer; }

    /* Estados de la fila entera (Figma: hover y pressed aplican a la card). */
    :host([fila-hover]) .fila { background: var(--color-bg-tertiary); }
    :host([fila-hover]) .main { background: var(--color-bg-tertiary); }
    :host([fila-pressed]) .fila { background: var(--color-bg-quaternary); }
    :host([fila-pressed]) .main { background: var(--color-bg-quaternary); }

    /* Foco de teclado: no está definido en Figma (su variante "focus" es en
       realidad el estado expandido), así que se agrega por accesibilidad. */
    :host(:focus-visible) .fila {
      outline: 2px solid var(--color-border-focus);
      outline-offset: 2px;
    }

    /* Las 5 columnas de datos son iguales; la de botones es fija. */
    .col {
      flex: 1 1 0;
      min-width: 0;
      display: flex;
      flex-direction: column;
    }

    /* --- 1. ID + agrupación --- */
    .col-id {
      flex-direction: row;
      align-items: center;
      gap: 16px;
    }
    .id-bloque {
      display: flex;
      flex-direction: column;
      gap: 3px;
      min-width: 0;
    }
    .id {
      font-size: var(--font-size-base);
      line-height: var(--line-height-base);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
      white-space: nowrap;
    }
    .agrupacion {
      display: flex;
      align-items: center;
      gap: var(--space-2);
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
    }
    .agrupacion-label { color: var(--color-text-brand); }
    :host([agrupacion="individual"]) .agrupacion-label { color: var(--color-text-tertiary); }
    :host([agrupacion="individual"]) .hijas-count { display: none; }

    /* --- 2. tipo + estado --- */
    .col-tipo {
      align-items: flex-start;
      gap: 10px;
    }

    /* --- 3, 4, 5 --- */
    .campo {
      display: flex;
      align-items: center;
      gap: var(--space-1);
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
      color: var(--color-text-tertiary);
      white-space: nowrap;
      min-width: 0;
    }
    .campo b {
      font-weight: var(--font-weight-bold);
      color: var(--color-text-secondary);
    }
    .campo svg { flex-shrink: 0; }

    /* Fechas y cifras son columnas contiguas y el ojo las lee como una
       tabla: sus dos líneas TIENEN que caer a la misma altura. En vez de
       confiar en que las alturas coincidan por casualidad (las fechas son
       texto de 16px y las cifras llevan un ícono de 21px), se les fija a
       ambas la misma altura de línea y el mismo gap. */
    .col-fechas { gap: var(--space-1); }
    .col-cifras { gap: var(--space-1); }
    .col-fechas .campo,
    .col-cifras .campo {
      min-height: 21px;
      align-items: center;
    }

    /* Las cifras nunca se recortan: si no caben, el campo baja de línea
       (así lo resuelve Figma en el modal, donde la fila es más angosta).
       Recortar un número lo vuelve mentira — "3." en vez de "305". */
    .col-cifras .campo { white-space: normal; }

    /* El OLT tampoco se recorta: baja de línea. Un OLT a medias
       ("OLT-STGO-CEN...") no sirve para identificar el equipo, y en Figma
       la fila angosta del modal justamente lo parte en dos líneas. */
    .col-olt .campo {
      white-space: normal;
      align-items: flex-start;
    }

    /* --- 6. botones + responsable --- */
    .col-fin {
      flex: 0 0 184px;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: var(--space-2);
    }
    .responsable {
      display: flex;
      align-items: center;
      gap: var(--space-2);
      flex: 0 0 auto;
    }
    .avatar {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 30px;
      flex-shrink: 0;
      background: var(--color-bg-secondary);
      border: 1px solid var(--color-border-default);
      border-radius: var(--radius-full);
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-secondary);
    }
    /* Incidencia asignada al usuario actual (feature de Fase 1, se conserva
       — ver DIFF-FASE2.md, P18). */
    :host([propia]) .avatar {
      background: var(--color-bg-brand);
      border-color: transparent;
      color: var(--color-text-inverse);
    }
    .responsable-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
    }
    .responsable-nombre {
      font-weight: var(--font-weight-bold);
      color: var(--color-text-secondary);
      white-space: nowrap;
    }
    .responsable-rol { color: var(--color-text-tertiary); }

    .buttons {
      display: flex;
      align-items: center;
      gap: var(--space-2);
      flex: 0 0 auto;
    }

    /* Dentro de un modal la fila solo describe de qué incidencia se habla:
       las acciones las da el propio modal. Se ocultan los botones y el
       chevron, pero el responsable SÍ se mantiene (así está en Figma —
       ver Modal_cambio_asignacion 441:4275, donde la incidencia actual
       muestra a su responsable). */
    :host([compacta]) .buttons { display: none; }
    :host([compacta]) .expand { display: none; }
    :host([compacta]) .col-id { gap: 0; }
    :host([compacta]) .main { cursor: default; }
    :host([compacta]) .col-fin {
      flex: 1 1 0;
      justify-content: flex-start;
    }

    /* --- bloque de hijas --- */
    .hijas {
      padding: var(--space-3) 25px;
      background: var(--color-bg-tertiary);
      border-top: 1px solid var(--color-border-strong);
    }
    :host(:not([expandido])) .hijas { display: none; }

    .hijas-list {
      display: flex;
      flex-direction: column;
      gap: var(--space-2);
      margin-bottom: var(--space-3);
    }
    .hijas-vacio {
      font-size: var(--font-size-xs);
      color: var(--color-text-tertiary);
    }
    .hijas-pag[hidden] { display: none; }
  </style>

  <div class="fila">
    <div class="main">
      <div class="col col-id">
        <ares-expand-button class="expand"></ares-expand-button>
        <span class="id-bloque">
          <span class="id"></span>
          <span class="agrupacion">
            <span class="agrupacion-label"></span>
            <ares-count-badge class="hijas-count"></ares-count-badge>
          </span>
        </span>
      </div>

      <div class="col col-tipo">
        <ares-problema-tag></ares-problema-tag>
        <ares-status-badge></ares-status-badge>
      </div>

      <div class="col col-fechas">
        <span class="campo">Creación <b class="f-creacion"></b></span>
        <span class="campo">Inicio Real <b class="f-inicio"></b></span>
      </div>

      <div class="col col-cifras">
        <span class="campo">${ICON_AFECTACION} Afectación Total: <b class="afectacion"></b></span>
        <span class="campo">${ICON_ALARMAS} Alarmas Totales: <b class="alarmas"></b></span>
      </div>

      <div class="col col-olt">
        <span class="campo">OLT <b class="olt"></b></span>
      </div>

      <div class="col-fin">
        <div class="responsable">
          <span class="avatar"></span>
          <span class="responsable-info">
            <span class="responsable-nombre"></span>
            <span class="responsable-rol"></span>
          </span>
        </div>
        <div class="buttons">
          <ares-button class="btn-detalles">Detalles</ares-button>
          <ares-button class="btn-tomar" intent="primary">Tomar INC</ares-button>
        </div>
      </div>
    </div>

    <div class="hijas">
      <div class="hijas-list"></div>
      <ares-pagination class="hijas-pag"></ares-pagination>
    </div>
  </div>
`;

class AresIncidentRow extends HTMLElement {
  static get observedAttributes() {
    return ['variante', 'expandido', 'compacta'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._data = null;
    this._paginaHijas = 1;
    this._els = {
      main: this.shadowRoot.querySelector('.main'),
      expand: this.shadowRoot.querySelector('.expand'),
      id: this.shadowRoot.querySelector('.id'),
      agrupacionLabel: this.shadowRoot.querySelector('.agrupacion-label'),
      hijasCount: this.shadowRoot.querySelector('.hijas-count'),
      tag: this.shadowRoot.querySelector('ares-problema-tag'),
      badge: this.shadowRoot.querySelector('ares-status-badge'),
      fCreacion: this.shadowRoot.querySelector('.f-creacion'),
      fInicio: this.shadowRoot.querySelector('.f-inicio'),
      afectacion: this.shadowRoot.querySelector('.afectacion'),
      alarmas: this.shadowRoot.querySelector('.alarmas'),
      olt: this.shadowRoot.querySelector('.olt'),
      colFin: this.shadowRoot.querySelector('.col-fin'),
      responsableBlock: this.shadowRoot.querySelector('.responsable'),
      avatar: this.shadowRoot.querySelector('.avatar'),
      nombre: this.shadowRoot.querySelector('.responsable-nombre'),
      rol: this.shadowRoot.querySelector('.responsable-rol'),
      btnDetalles: this.shadowRoot.querySelector('.btn-detalles'),
      btnTomar: this.shadowRoot.querySelector('.btn-tomar'),
      hijasList: this.shadowRoot.querySelector('.hijas-list'),
      hijasPag: this.shadowRoot.querySelector('.hijas-pag'),
    };
    this._upgradeProperty('data');

    // Los botones son islas: su click no debe desplegar la fila.
    this._els.btnDetalles.addEventListener('click', (e) => {
      e.stopPropagation();
      this._emitir('ares-detalles', { id: this._idActual() });
    });
    this._els.btnTomar.addEventListener('click', (e) => {
      e.stopPropagation();
      this._emitir('ares-tomar-inc', { id: this._idActual() });
    });

    this._els.expand.addEventListener('ares-toggle-expandir', (e) => {
      e.stopPropagation();
      this._aplicarExpandido(e.detail.expandido);
    });
    // El chevron ya alterna por su cuenta; sin esto el click llegaría también
    // a la fila y volvería a alternar, cancelando el efecto.
    this._els.expand.addEventListener('click', (e) => e.stopPropagation());

    /* Click en cualquier parte de la card. En Figma toda la fila despliega,
       no solo el chevron. */
    this._els.main.addEventListener('click', () => {
      if (!this._esExpandible()) return;
      this._aplicarExpandido(!this.hasAttribute('expandido'));
    });

    /* Estados visuales de la card completa. El chevron tiene que reflejar el
       mismo estado, y no se puede alcanzar su shadow DOM desde el CSS de acá:
       se le pasa como atributo. */
    this._els.main.addEventListener('mouseenter', () => this._estadoFila('fila-hover', true));
    this._els.main.addEventListener('mouseleave', () => {
      this._estadoFila('fila-hover', false);
      this._estadoFila('fila-pressed', false);
    });
    this._els.main.addEventListener('mousedown', () => {
      if (this._esExpandible()) this._estadoFila('fila-pressed', true);
    });
    this._els.main.addEventListener('mouseup', () => this._estadoFila('fila-pressed', false));

    // Mismo criterio: la hija sabe su id, pero no el del padre.
    this.shadowRoot.addEventListener('ares-detalles-hija', (e) => {
      e.stopPropagation();
      this._emitir('ares-detalles-hija', { id: e.detail.id, padreId: this._idActual() });
    });

    this._els.hijasPag.addEventListener('ares-cambio-pagina', (e) => {
      e.stopPropagation();
      this._paginaHijas = e.detail.pagina;
      this._renderHijas();
    });
    // La paginación de las hijas vive dentro de la card: sus clicks no la colapsan.
    this._els.hijasPag.addEventListener('click', (e) => e.stopPropagation());
  }

  connectedCallback() {
    this._syncVariante();
    this._syncExpandido();
  }

  attributeChangedCallback(name) {
    if (name === 'expandido') this._syncExpandido();
    else this._syncVariante();
  }

  // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
  _upgradeProperty(prop) {
    if (Object.prototype.hasOwnProperty.call(this, prop)) {
      const value = this[prop];
      delete this[prop];
      this[prop] = value;
    }
  }

  /** @param {import('../types.js').IncidentRowData} value */
  set data(value) {
    this._data = value;
    this._paginaHijas = 1;
    this._render();
  }

  get data() {
    return this._data;
  }

  _idActual() {
    return this._data?.incidencia?.id;
  }

  _hijas() {
    return this._data?.incidencia?.hijas || [];
  }

  _esExpandible() {
    return (
      !this.hasAttribute('compacta') &&
      this.getAttribute('agrupacion') === 'consolidacion' &&
      this._hijas().length > 0
    );
  }

  _emitir(nombre, detail) {
    this.dispatchEvent(new CustomEvent(nombre, { detail, bubbles: true, composed: true }));
  }

  // Refleja el estado de la card en el host y en el chevron a la vez.
  _estadoFila(attr, on) {
    this.toggleAttribute(attr, on);
    this._els.expand.toggleAttribute(attr, on);
  }

  _aplicarExpandido(expandido) {
    this.toggleAttribute('expandido', expandido);
    this._emitir('ares-toggle-expandir', { id: this._idActual(), expandido });
  }

  _syncVariante() {
    const variante = this.getAttribute('variante') || 'pendiente';
    /* El responsable NO depende de `compacta`: dentro del modal de cambio de
       asignación la incidencia actual sí muestra a su responsable (Figma
       441:4275). Lo que `compacta` oculta son los botones y el chevron.

       Pero sí depende de que HAYA un responsable en los datos: sin esta
       comprobación el bloque se reservaba igual y se veía un avatar vacío
       (un círculo de color sin iniciales ni nombre), que es lo que pasaba
       en los modales de gestión — su incidenteDetalle no trae responsable. */
    const hayResponsable = !!this._data?.responsable?.nombre;
    const showResponsable = hayResponsable && (variante === 'en-curso' || variante === 'historico');
    this._els.responsableBlock.style.display = showResponsable ? '' : 'none';
    this._els.btnTomar.style.display = variante === 'pendiente' ? '' : 'none';

    /* En modo compacto no hay botones; si además no hay responsable, la
       última columna queda vacía y solo robaría ancho a las demás. */
    const finVacia = this.hasAttribute('compacta') && !showResponsable;
    this._els.colFin.style.display = finVacia ? 'none' : '';
  }

  _syncExpandido() {
    const expandido = this.hasAttribute('expandido');
    // Mantiene el chevron en sincronía si el atributo cambia desde afuera.
    this._els.expand.toggleAttribute('expandido', expandido);
    if (expandido) this._renderHijas();
  }

  _render() {
    const d = this._data;
    if (!d) return;
    const inc = d.incidencia;

    this._els.id.textContent = inc.id;
    this._els.tag.setAttribute('tipo', inc.tipoIncidente);
    this._els.badge.setAttribute('status', inc.estado);
    this._els.fCreacion.textContent = inc.fechaCreacion;
    this._els.fInicio.textContent = inc.fechaInicioReal;
    this._els.afectacion.textContent = inc.afectacionTotal;
    this._els.alarmas.textContent = inc.alarmasTotal;
    this._els.olt.textContent = inc.olt || '—';

    /* Consolidación vs Individual. Si no viene `agrupacion` se deduce de si
       hay hijas, para que un mock viejo no rompa la fila. */
    const hijas = this._hijas();
    const agrupacion = inc.agrupacion || (hijas.length ? 'consolidacion' : 'individual');
    this.setAttribute('agrupacion', agrupacion);
    const esConsolidacion = agrupacion === 'consolidacion';

    this._els.agrupacionLabel.textContent = esConsolidacion ? 'Consolidación' : 'Individual';
    this._els.hijasCount.textContent = hijas.length;

    this._els.expand.toggleAttribute('disabled', !this._esExpandible());
    this._els.expand.setAttribute(
      'label',
      esConsolidacion ? `Ver incidencias correlacionadas de ${inc.id}` : 'Incidencia individual'
    );

    this.toggleAttribute('propia', !!d.esPropia);
    if (d.responsable) {
      this._els.avatar.textContent = d.responsable.iniciales;
      this._els.nombre.textContent = d.responsable.nombre;
      this._els.rol.textContent = d.esPropia ? 'Tu Incidencia' : 'Responsable';
    }

    this._syncVariante();
    if (this.hasAttribute('expandido')) this._renderHijas();
  }

  _renderHijas() {
    const hijas = this._hijas();
    const lista = this._els.hijasList;
    lista.innerHTML = '';

    if (hijas.length === 0) {
      const vacio = document.createElement('p');
      vacio.className = 'hijas-vacio';
      vacio.textContent = 'Esta incidencia no tiene incidencias correlacionadas.';
      lista.appendChild(vacio);
      this._els.hijasPag.hidden = true;
      return;
    }

    const totalPaginas = Math.max(1, Math.ceil(hijas.length / HIJAS_POR_PAGINA));
    this._paginaHijas = Math.min(this._paginaHijas, totalPaginas);
    const inicio = (this._paginaHijas - 1) * HIJAS_POR_PAGINA;

    hijas.slice(inicio, inicio + HIJAS_POR_PAGINA).forEach((hija) => {
      const fila = document.createElement('ares-correlated-row');
      fila.data = hija;
      lista.appendChild(fila);
    });

    this._els.hijasPag.hidden = totalPaginas === 1;
    this._els.hijasPag.setAttribute('total-paginas', totalPaginas);
    this._els.hijasPag.setAttribute('pagina', this._paginaHijas);
  }
}

if (!customElements.get('ares-incident-row')) {
  customElements.define('ares-incident-row', AresIncidentRow);
}
})();
