(function () {
'use strict';

/**
 * <ares-alarma-badge>
 *
 * Badge de estado en la columna "Estado" de la tabla de alarmas.
 *
 * Atributo:
 *   estado   "abierto" | "cerrado"
 */

const LABELS = {
  abierto: "Abierto",
  cerrado: "Cerrado",
};

const TEMPLATE = document.createElement("template");
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      font-family: var(--font-family-base);
    }

    .badge {
      display: inline-flex;
      align-items: center;
      gap: var(--space-1);
      padding: var(--space-1) var(--space-2);
      border: 1px solid;
      border-radius: var(--radius-pill);
    }

    .dot {
      width: 6px;
      height: 6px;
      border-radius: var(--radius-full);
      flex-shrink: 0;
    }

    .label {
      font-size: var(--font-size-xs);
      line-height: var(--line-height-caption);
      font-weight: var(--font-weight-bold);
      white-space: nowrap;
    }

    :host([estado="abierto"]) .badge,
    :host(:not([estado])) .badge {
      background: var(--color-corporate-50);
      border-color: var(--color-corporate-400);
    }
    :host([estado="abierto"]) .dot,
    :host(:not([estado])) .dot {
      background: var(--color-corporate-500);
    }
    :host([estado="abierto"]) .label,
    :host(:not([estado])) .label {
      color: var(--color-text-brand);
    }

    :host([estado="cerrado"]) .badge {
      background: var(--color-bg-tertiary);
      border-color: var(--color-border-strong);
    }
    :host([estado="cerrado"]) .dot {
      background: var(--color-text-tertiary);
    }
    :host([estado="cerrado"]) .label {
      color: var(--color-text-secondary);
    }
  </style>
  <span class="badge">
    <span class="dot"></span>
    <span class="label"></span>
  </span>
`;

class AresAlarmaBadge extends HTMLElement {
  static get observedAttributes() {
    return ["estado"];
  }

  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._label = this.shadowRoot.querySelector(".label");
  }

  connectedCallback() {
    this._sync();
  }

  attributeChangedCallback() {
    this._sync();
  }

  _sync() {
    this._label.textContent =
      LABELS[this.getAttribute("estado")] || LABELS.abierto;
  }
}

if (!customElements.get("ares-alarma-badge")) {
  customElements.define("ares-alarma-badge", AresAlarmaBadge);
}
})();
