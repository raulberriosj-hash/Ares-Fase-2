(function () {
  "use strict";

  /**
   * <ares-kpi-bar-detallada>
   *
   * Tarjeta "VNOs Afectadas" del header de bandeja (chips por carrier).
   * Distinto componente de ares-kpi-bar-resumen (tarjeta título+valor).
   *
   * Tipo de dato: KpiBarDetalladaData (ver types.js).
   */

  const TEMPLATE = document.createElement("template");
  TEMPLATE.innerHTML = `
  <style>
    :host {
      /* Fill: ocupa el espacio horizontal disponible en vez de ancho fijo. */
      display: flex;
      flex: 1 1 280px;
      min-width: 0;
      font-family: var(--font-family-base);
    }
    .card {
      display: flex;
      flex-direction: column;
      gap: var(--space-2);
      align-items: flex-start;
      padding: var(--space-2);
      border-radius: var(--radius-md);
      background: var(--color-bg-primary);
      width: 100%;
      box-sizing: border-box;
    }
    :host(:hover) .card {
      background: var(--color-bg-quaternary);
    }
    .title {
      font-size: var(--font-size-base);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
      white-space: nowrap;
    }
    .tags {
      display: flex;
      flex-wrap: wrap;
      gap: var(--space-2);
      width: 100%;
    }
    .tag {
      display: inline-flex;
      gap: var(--space-1);
      padding: var(--space-1) var(--space-2);
      background: var(--color-bg-secondary);
      border: 1px solid var(--color-border-default);
      border-radius: var(--radius-sm);
      font-size: var(--font-size-xs);
      color: var(--color-text-secondary);
      white-space: nowrap;
    }
    .tag b {
      font-weight: var(--font-weight-bold);
    }
  </style>
  <div class="card">
    <span class="title">VNOs Afectadas</span>
    <div class="tags"></div>
  </div>
`;

  class AresKpiBarDetallada extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: "open" });
      this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
      this._data = null;
      this._tags = this.shadowRoot.querySelector(".tags");
      this._upgradeProperty("data");
    }

    // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
    _upgradeProperty(prop) {
      if (Object.prototype.hasOwnProperty.call(this, prop)) {
        const value = this[prop];
        delete this[prop];
        this[prop] = value;
      }
    }

    /** @param {import('../types.js').KpiBarDetalladaData} value */
    set data(value) {
      this._data = value;
      this._render();
    }

    get data() {
      return this._data;
    }

    _render() {
      const d = this._data;
      if (!d) return;
      this._tags.innerHTML = "";
      (d.vnos || []).forEach((vno) => {
        const tag = document.createElement("span");
        tag.className = "tag";
        const label = document.createElement("span");
        label.textContent = `${vno.carrier} · `;
        const count = document.createElement("b");
        count.textContent = String(vno.count);
        tag.appendChild(label);
        tag.appendChild(count);
        this._tags.appendChild(tag);
      });
    }
  }

  if (!customElements.get("ares-kpi-bar-detallada")) {
    customElements.define("ares-kpi-bar-detallada", AresKpiBarDetallada);
  }
})();
