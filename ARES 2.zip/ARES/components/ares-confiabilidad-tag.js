(function () {
  'use strict';

  /**
   * <ares-confiabilidad-tag>
   *
   * Score de confianza de una incidencia hija dentro de una consolidación:
   * el texto fijo "Confiabilidad" seguido del porcentaje, coloreado según
   * qué tan alta sea la correlación propuesta.
   *
   * Nuevo en Fase 2 (ver DIFF-FASE2.md, N4). Hoy solo aparece en la fila
   * expandida de la bandeja; la tabla "Incidencias Correlacionadas" del
   * detalle lista las mismas hijas pero sin el score (ver P12).
   *
   * Atributos:
   *   valor   DATA-INPUT. Número 0–100 (sin el "%"). Ej. valor="90".
   *   nivel   Opcional: "alto" | "medio" | "bajo". Fuerza el color.
   *           Si no se define, se deriva de `valor` con los umbrales de
   *           abajo. Se expone para que el día que el backend entregue el
   *           nivel ya calculado no haya que duplicar la regla acá.
   *
   * DISEÑO-PENDIENTE: los umbrales no están confirmados (ver DIFF-FASE2.md,
   * P2). El Figma solo muestra tres ejemplos — 90% verde, 60% naranja y
   * 1% rojo — que no bastan para deducir dónde están los cortes. Se asume
   * el reparto de abajo hasta que diseño lo confirme; cambiarlo es editar
   * UMBRALES y nada más.
   */

  /* alto: valor >= 80 · medio: 40–79 · bajo: < 40 */
  const UMBRALES = { alto: 80, medio: 40 };

  function nivelDesdeValor(valor) {
    if (valor >= UMBRALES.alto) return 'alto';
    if (valor >= UMBRALES.medio) return 'medio';
    return 'bajo';
  }

  const TEMPLATE = document.createElement('template');
  TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      align-items: baseline;
      gap: var(--space-1);
      font-family: var(--font-family-base);
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
    }

    .etiqueta {
      color: var(--color-text-tertiary);
      white-space: nowrap;
    }

    .valor {
      font-weight: var(--font-weight-bold);
      white-space: nowrap;
      /* Fallback: si no hay nivel resuelto todavía, no queda invisible. */
      color: var(--color-text-secondary);
    }

    :host([nivel="alto"]) .valor { color: var(--color-text-success); }
    :host([nivel="medio"]) .valor { color: var(--color-text-warning); }
    :host([nivel="bajo"]) .valor { color: var(--color-text-error); }
  </style>
  <span class="etiqueta">Confiabilidad</span><span class="valor"></span>
`;

  class AresConfiabilidadTag extends HTMLElement {
    static get observedAttributes() {
      return ['valor', 'nivel'];
    }

    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
      this._valor = this.shadowRoot.querySelector('.valor');
      this._upgradeProperty('valor');
      this._upgradeProperty('nivel');
    }

    // Recupera la propiedad si se asignó antes de que el elemento hiciera upgrade.
    _upgradeProperty(prop) {
      if (Object.prototype.hasOwnProperty.call(this, prop)) {
        const value = this[prop];
        delete this[prop];
        this[prop] = value;
      }
    }

    set valor(v) {
      this.setAttribute('valor', v);
    }

    get valor() {
      return Number(this.getAttribute('valor'));
    }

    set nivel(v) {
      if (v) this.setAttribute('nivel', v);
      else this.removeAttribute('nivel');
    }

    get nivel() {
      return this.getAttribute('nivel');
    }

    connectedCallback() {
      this._sync();
    }

    attributeChangedCallback() {
      this._sync();
    }

    _sync() {
      const crudo = this.getAttribute('valor');
      const valor = Number(crudo);

      if (crudo === null || crudo === '' || Number.isNaN(valor)) {
        this._valor.textContent = '';
        return;
      }

      this._valor.textContent = `${valor}%`;

      // `nivel` explícito manda; si no viene, se deriva del valor.
      if (!this.hasAttribute('nivel')) {
        // Evita re-entrar en attributeChangedCallback en loop: setAttribute
        // dispara _sync otra vez, pero en esa pasada el atributo ya existe.
        this.setAttribute('nivel', nivelDesdeValor(valor));
      }
    }
  }

  if (!customElements.get('ares-confiabilidad-tag')) {
    customElements.define('ares-confiabilidad-tag', AresConfiabilidadTag);
  }
})();
