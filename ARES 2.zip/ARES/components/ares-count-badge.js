(function () {
'use strict';

/**
 * <ares-count-badge>
 *
 * Contador numérico simple, usado junto a íconos de warning/alarmas.
 *
 * Slot:
 *   (default)  el número/texto del contador (DATA-INPUT)
 */

const TEMPLATE = document.createElement("template");
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      font-family: var(--font-family-base);
    }

    .badge {
      display: inline-flex;
      align-items: center;
      padding: var(--space-1) var(--space-2);
      background: var(--color-bg-secondary);
      border: 1px solid var(--color-border-default);
      border-radius: var(--radius-pill);
      /* ::slotted(*) no matchea texto plano — se fija acá en vez de ahí. */
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-tertiary);
      white-space: nowrap;
    }
  </style>
  <span class="badge"><slot></slot></span>
`;

class AresCountBadge extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
  }
}

if (!customElements.get("ares-count-badge")) {
  customElements.define("ares-count-badge", AresCountBadge);
}
})();
