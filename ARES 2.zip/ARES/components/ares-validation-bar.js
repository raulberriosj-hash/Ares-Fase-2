(function () {
'use strict';

/**
 * <ares-validation-bar>
 *
 * Barra inferior fija del detalle de gestión de incidencia.
 *
 * Fase 2 (ver DIFF-FASE2.md, M2): la aprobación pasó a tener dos etapas, así
 * que la barra tiene 2 variantes con copy, color e ícono distintos. Primero
 * se validan las Evidencias; recién ahí aparece la barra de Correlación.
 * En los estados terminales no se muestra ninguna — en su lugar va un
 * <ares-notification-banner> arriba del contenido.
 *
 * Atributos:
 *   variante          "evidencias" (default) | "correlacion"
 *   puede-gestionar   boolean — controla si la barra se muestra. Sigue
 *                     siendo necesario pero ya no suficiente: además hay
 *                     que elegir la variante según la etapa del flujo.
 *
 * Tipo de dato: ValidationBarData (ver types.js).
 *
 * Eventos (los nombres se mantienen desde Fase 1 para no romper a los
 * consumidores; ahora llevan `detail` para distinguir qué se aprobó):
 *   ares-aprobar-consolidacion    detail: { variante }
 *   ares-rechazar-consolidacion   detail: { variante }
 */

const COPY = {
  evidencias: {
    titulo: 'Validación de consolidación de Evidencias',
    unidad: (n) => `${n} alarmas`,
    aprobar: 'Aprobar Evidencias',
  },
  correlacion: {
    titulo: 'Validación Incidencias Correlacionadas',
    unidad: (n) => `${n} INC correlacionadas`,
    aprobar: 'Aprobar correlación de Incidentes',
  },
};

/* DISEÑO-PENDIENTE menor: faltan exportar desde Figma los assets definitivos
   (`ic/alarm` 2103:2771 y `si:ai-note-line` 2103:2783). Estos son
   equivalentes dibujados a mano con la misma métrica de 24×24. */
const ICON_SIRENA =
  '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 17v-4a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M5 20h14" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M12 4V2M5 8 3.5 6.5M19 8l1.5-1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';

const ICON_CORRELACION =
  '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="3" width="13" height="18" rx="2" stroke="currentColor" stroke-width="1.6"/><path d="M8 9h5M8 13h5M8 17h3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="m18.5 3 .8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z" fill="currentColor"/></svg>';

const CHECK_ICON =
  '<svg slot="icon-start" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3333 4L6 11.3333L2.66667 8" stroke="currentColor" stroke-width="1.6"/></svg>';

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: none;
      font-family: var(--font-family-base);
    }
    :host([puede-gestionar]) {
      display: block;
    }
    .bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: var(--space-3);
      padding: var(--space-3) var(--space-6);
      border-radius: var(--radius-md);
      flex-wrap: wrap;
      /* Default = evidencias. Si llega una variante desconocida, la barra
         cae acá en vez de quedar sin fondo. */
      background: var(--color-bg-inverse-brand);
    }
    :host([variante="correlacion"]) .bar {
      background: var(--color-bg-inverse-support);
    }
    .info {
      display: flex;
      align-items: center;
      gap: var(--space-2);
    }
    .icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      flex-shrink: 0;
      border-radius: var(--radius-full);
      background: var(--color-bg-brand);
      color: var(--color-text-inverse);
    }
    :host([variante="correlacion"]) .icon {
      background: var(--color-interactive-secondary);
    }
    /* Un ícono por variante: se alternan por CSS en vez de reescribir
       innerHTML en cada render. */
    .icon-evidencias,
    .icon-correlacion {
      display: flex;
    }
    :host(:not([variante="correlacion"])) .icon-correlacion,
    :host([variante="correlacion"]) .icon-evidencias {
      display: none;
    }
    .text {
      display: flex;
      flex-direction: column;
    }
    .title {
      font-size: var(--font-size-base);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-inverse);
    }
    .subtitle {
      font-size: var(--font-size-xs);
      color: var(--color-neutral-300);
    }
    .actions {
      display: flex;
      gap: var(--space-2);
    }
  </style>
  <div class="bar">
    <div class="info">
      <span class="icon">
        <span class="icon-evidencias">${ICON_SIRENA}</span>
        <span class="icon-correlacion">${ICON_CORRELACION}</span>
      </span>
      <div class="text">
        <span class="title"></span>
        <span class="subtitle"><span class="unidad"></span> · Nada se escribe en ServiceNow sin tu aprobación</span>
      </div>
    </div>
    <div class="actions">
      <ares-button class="btn-rechazar" intent="destructive">Rechazar</ares-button>
      <ares-button class="btn-aprobar" intent="primary" tone="success">${CHECK_ICON}<span class="txt-aprobar"></span></ares-button>
    </div>
  </div>
`;

class AresValidationBar extends HTMLElement {
  static get observedAttributes() {
    return ['variante'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._data = null;
    this._els = {
      titulo: this.shadowRoot.querySelector('.title'),
      unidad: this.shadowRoot.querySelector('.unidad'),
      txtAprobar: this.shadowRoot.querySelector('.txt-aprobar'),
    };
    this.shadowRoot.querySelector('.btn-rechazar').addEventListener('click', () => {
      this.dispatchEvent(new CustomEvent('ares-rechazar-consolidacion', {
        detail: { variante: this._variante() }, bubbles: true, composed: true,
      }));
    });
    this.shadowRoot.querySelector('.btn-aprobar').addEventListener('click', () => {
      this.dispatchEvent(new CustomEvent('ares-aprobar-consolidacion', {
        detail: { variante: this._variante() }, bubbles: true, composed: true,
      }));
    });
    this._upgradeProperty('data');
  }

  connectedCallback() {
    this._render();
  }

  attributeChangedCallback() {
    this._render();
  }

  // Variante efectiva: cualquier valor no reconocido cae en "evidencias".
  _variante() {
    const v = this.getAttribute('variante');
    return COPY[v] ? v : 'evidencias';
  }

  // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
  _upgradeProperty(prop) {
    if (Object.prototype.hasOwnProperty.call(this, prop)) {
      const value = this[prop];
      delete this[prop];
      this[prop] = value;
    }
  }

  /** @param {import('../types.js').ValidationBarData} value */
  set data(value) {
    this._data = value;
    this._render();
  }

  get data() {
    return this._data;
  }

  _render() {
    const variante = this._variante();
    const copy = COPY[variante];

    this._els.titulo.textContent = copy.titulo;
    this._els.txtAprobar.textContent = copy.aprobar;

    // El título y el botón no dependen de .data, así que se pintan siempre.
    // El subtítulo sí: lleva el conteo.
    const d = this._data;
    if (!d) return;

    const n = variante === 'correlacion' ? d.incCorrelacionadasCount : d.alarmasCount;
    this._els.unidad.textContent = copy.unidad(n ?? 0);
  }
}

if (!customElements.get('ares-validation-bar')) {
  customElements.define('ares-validation-bar', AresValidationBar);
}
})();
