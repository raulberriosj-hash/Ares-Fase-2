(function () {
'use strict';

/**
 * <ares-validation-modal>
 *
 * Modal de aprobar/rechazar consolidación — mismo layout, título y botón
 * cambian según `accion`.
 *
 * Atributos:
 *   open       boolean — controla visibilidad
 *   accion     "aprobar" | "rechazar"
 *   variante   "evidencias" (default) | "correlacion"
 *
 * Fase 2 (ver DIFF-FASE2.md, N7): la aprobación tiene dos etapas, así que el
 * Figma pasó de 2 modales a 4 (aprobar/rechazar × evidencia/correlación).
 * Acá se resuelve con el mismo componente cruzando `accion` × `variante`, en
 * vez de duplicarlo: el layout es idéntico, solo cambia la copy.
 *
 * Tipo de dato: ValidationModalData (ver types.js).
 *
 * Eventos:
 *   ares-cancel     click en "Volver" o en el ícono de cierre
 *   ares-confirmar  click en el botón de acción. detail: { id, accion }
 */

const CLOSE_ICON =
  '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="1.33333"/></svg>';
const CHECK_ICON =
  '<svg slot="icon-start" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3333 4L6 11.3333L2.66667 8" stroke="currentColor" stroke-width="1.6"/></svg>';

/* Ícono del título, uno por variante. Mismos glifos y mismos colores que
   los círculos de <ares-validation-bar>, para que se lea como la misma
   gestión: evidencias en teal (#00BFD6 = Background/Brand) y correlación en
   morado (#6C63FF = Interactive/Secondary), muestreados del Figma.
   DISEÑO-PENDIENTE menor: faltan los assets definitivos (ic/alarm 2103:2771
   y si:ai-note-line 2103:2783); estos son equivalentes dibujados a mano. */
const ICON_SIRENA =
  '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 17v-4a5 5 0 0 1 10 0v4" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M5 20h14" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M12 4V2M5 8 3.5 6.5M19 8l1.5-1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';

const ICON_CORRELACION =
  '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="3" width="13" height="18" rx="2" stroke="currentColor" stroke-width="1.6"/><path d="M8 9h5M8 13h5M8 17h3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="m18.5 3 .8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z" fill="currentColor"/></svg>';

const COPY = {
  evidencias: {
    aprobar: {
      titulo: (id) => `Aprobar Evidencia ${id}`,
      descripcion:
        'Al aprobar esta consolidación, la evidencia validada se registrará en ServiceNow y el incidente avanzará a la siguiente etapa de gestión. Esta acción quedará asociada a tu nombre y no se puede deshacer.',
      boton: 'Aprobar Evidencias',
    },
    rechazar: {
      titulo: (id) => `Rechazar Evidencia ${id}`,
      descripcion:
        'Al rechazar esta consolidación, la evidencia no se registrará en ServiceNow y el incidente deberá gestionarse internamente a través de ServiceNow. Esta acción quedará asociada a tu nombre y no se puede deshacer.',
      boton: 'Rechazar',
    },
  },
  correlacion: {
    aprobar: {
      titulo: (id) => `Aprobar Correlación ${id}`,
      descripcion:
        'Al aprobar esta correlación, las incidencias correlacionadas se registrarán como un mismo evento en ServiceNow. Esta acción quedará asociada a tu nombre y no se puede deshacer.',
      boton: 'Aprobar correlación de Incidentes',
    },
    rechazar: {
      titulo: (id) => `Rechazar Correlación ${id}`,
      descripcion:
        'Al rechazar esta correlación, las incidencias no se agruparán y deberán gestionarse internamente a través de ServiceNow. Esta acción quedará asociada a tu nombre y no se puede deshacer.',
      boton: 'Rechazar',
    },
  },
};

// Variante desconocida (o ausente) cae en "evidencias", que es la primera etapa.
function copyDe(variante, accion) {
  const grupo = COPY[variante] || COPY.evidencias;
  return grupo[accion];
}

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: none;
      font-family: var(--font-family-base);
    }
    :host([open]) {
      display: flex;
      position: fixed;
      inset: 0;
      align-items: center;
      justify-content: center;
      padding: var(--space-4);
      background: var(--color-overlay-modal);
      z-index: 1000;
      box-sizing: border-box;
    }
    .dialog {
      display: flex;
      flex-direction: column;
      width: min(94vw, 1040px);
      max-height: 88vh;
      overflow: auto;
      background: var(--color-bg-primary);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-modal);
    }
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: var(--space-3);
      padding: var(--space-6);
      border-bottom: 1px solid var(--color-border-default);
    }
    .header h2 {
      margin: 0;
      font-size: var(--font-size-h3);
      line-height: var(--line-height-h3);
      letter-spacing: var(--letter-spacing-h3);
      font-weight: var(--font-weight-bold);
      color: var(--color-text-primary);
      /* El título ocupa el hueco entre el ícono y la ✕. */
      margin-right: auto;
    }

    /* Ícono distintivo de la gestión, a la izquierda del título. */
    .title-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      flex-shrink: 0;
      border-radius: var(--radius-full);
      background: var(--color-bg-brand);
      color: var(--color-text-inverse);
    }
    :host([variante="correlacion"]) .title-icon {
      background: var(--color-interactive-secondary);
    }
    .icon-evidencias,
    .icon-correlacion { display: flex; }
    /* Un glifo por variante; se alternan por CSS, sin rehacer el markup. */
    :host(:not([variante="correlacion"])) .icon-correlacion,
    :host([variante="correlacion"]) .icon-evidencias {
      display: none;
    }
    .body {
      display: flex;
      flex-direction: column;
      gap: var(--space-6);
      padding: var(--space-6);
      background: var(--color-bg-tertiary);
    }
    .body p {
      margin: 0;
      font-size: var(--font-size-base);
      line-height: var(--line-height-base);
      color: var(--color-text-primary);
    }
    .actions {
      display: flex;
      justify-content: flex-end;
      gap: var(--space-2);
    }
  </style>
  <div class="dialog" role="dialog" aria-modal="true">
    <div class="header">
      <span class="title-icon">
        <span class="icon-evidencias">${ICON_SIRENA}</span>
        <span class="icon-correlacion">${ICON_CORRELACION}</span>
      </span>
      <h2 class="title"></h2>
      <ares-icon-button class="btn-close" variant="neutral" label="Cerrar">${CLOSE_ICON}</ares-icon-button>
    </div>
    <div class="body">
      <p class="descripcion"></p>
      <ares-incident-row class="summary" compacta variante="en-curso"></ares-incident-row>
      <div class="actions">
        <ares-button class="btn-cancel">Volver</ares-button>
        <ares-button class="btn-confirmar" intent="destructive">Rechazar</ares-button>
      </div>
    </div>
  </div>
`;

class AresValidationModal extends HTMLElement {
  static get observedAttributes() {
    return ['accion', 'variante'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._data = null;
    this._els = {
      title: this.shadowRoot.querySelector('.title'),
      descripcion: this.shadowRoot.querySelector('.descripcion'),
      summary: this.shadowRoot.querySelector('.summary'),
      btnClose: this.shadowRoot.querySelector('.btn-close'),
      btnCancel: this.shadowRoot.querySelector('.btn-cancel'),
      btnConfirmar: this.shadowRoot.querySelector('.btn-confirmar'),
    };
    const cancel = () => this.dispatchEvent(new CustomEvent('ares-cancel', { bubbles: true, composed: true }));
    this._els.btnClose.addEventListener('click', cancel);
    this._els.btnCancel.addEventListener('click', cancel);
    this._els.btnConfirmar.addEventListener('click', () => {
      const accion = this.getAttribute('accion') || 'aprobar';
      this.dispatchEvent(
        new CustomEvent('ares-confirmar', {
          detail: { id: this._data?.incidencia?.id, accion },
          bubbles: true,
          composed: true,
        })
      );
    });
    this._upgradeProperty('data');
  }

  connectedCallback() {
    this._syncAccion();
  }

  attributeChangedCallback() {
    this._syncAccion();
  }

  // Recupera .data si se asignó antes de que el elemento hiciera upgrade.
  _upgradeProperty(prop) {
    if (Object.prototype.hasOwnProperty.call(this, prop)) {
      const value = this[prop];
      delete this[prop];
      this[prop] = value;
    }
  }

  /** @param {import('../types.js').ValidationModalData} value */
  set data(value) {
    this._data = value;
    this._render();
  }

  get data() {
    return this._data;
  }

  _syncAccion() {
    const accion = this.getAttribute('accion') || 'aprobar';
    const copy = copyDe(this.getAttribute('variante'), accion);
    const id = this._data?.incidencia?.id || '';
    this._els.title.textContent = copy.titulo(id);
    this._els.descripcion.textContent = copy.descripcion;

    this._els.btnConfirmar.textContent = '';
    if (accion === 'aprobar') {
      this._els.btnConfirmar.setAttribute('intent', 'primary');
      this._els.btnConfirmar.setAttribute('tone', 'success');
      this._els.btnConfirmar.insertAdjacentHTML('beforeend', CHECK_ICON + copy.boton);
    } else {
      this._els.btnConfirmar.setAttribute('intent', 'destructive');
      this._els.btnConfirmar.removeAttribute('tone');
      this._els.btnConfirmar.textContent = copy.boton;
    }
  }

  _render() {
    const d = this._data;
    if (!d) return;
    // Fase 2: <ares-incident-row> compacto (espera IncidentRowData).
    this._els.summary.data = {
      incidencia: d.incidencia,
      responsable: d.incidencia.responsable,
      esPropia: true, // solo se valida la incidencia que uno gestiona
    };
    this._syncAccion();
  }
}

if (!customElements.get('ares-validation-modal')) {
  customElements.define('ares-validation-modal', AresValidationModal);
}
})();
