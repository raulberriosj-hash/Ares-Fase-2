(function () {
'use strict';

/**
 * <ares-tooltip-flag>
 *
 * Flag sobre fila de alarma: dyinggasp, inconsistency, different-integration.
 * No son mutuamente excluyentes — para mostrar varios, colocar múltiples
 * <ares-tooltip-flag> seguidos (:host ya es inline-flex).
 *
 * Atributos:
 *   type      "dyinggasp" | "inconsistency" | "different-integration"
 *   creador   solo con type="different-integration" — quién/qué integración
 *             creó la alarma (ej. "Nokia NFM-P"). Lo entrega el consumidor
 *             del componente; si no se define, el popover no lo menciona.
 *
 * Slot:
 *   (default)  ícono del flag (SVG inline con fill/stroke="currentColor", no <img>)
 */

const COPY = {
  dyinggasp: {
    title: 'DYING GASP',
    description: 'El equipo del cliente reportó pérdida de energía antes de apagarse',
  },
  inconsistency: {
    title: 'Inconsistencia en la Alarma',
    description: 'No coincide la cantidad de alarmas en UA y ServiceNow',
  },
  'different-integration': {
    title: 'Creación Diferente',
    description: (creador) =>
      creador
        ? `Esta alarma fue creada por "${creador}" en lugar de BluePlanet`
        : 'Esta alarma fue creada por otra integración en lugar de BluePlanet',
  },
};

const TEMPLATE = document.createElement('template');
TEMPLATE.innerHTML = `
  <style>
    :host {
      display: inline-flex;
      position: relative;
      font-family: var(--font-family-base);
    }

    .chip {
      display: inline-flex;
      align-items: center;
      padding: var(--space-1);
      border: 1px solid;
      border-radius: var(--radius-sm);
    }

    ::slotted(*) {
      display: inline-flex;
      width: 18px;
      height: 18px;
      flex-shrink: 0;
    }

    .popover {
      /* Anclado al borde izquierdo del chip (no centrado): los flags están
         en la columna más a la izquierda de la tabla, junto al sidebar, y
         un popover centrado quedaría recortado por ese lado. */
      display: none;
      position: absolute;
      left: 0;
      top: calc(100% + var(--space-1));
      flex-direction: column;
      align-items: center;
      gap: var(--space-1);
      width: 220px;
      padding: var(--space-3);
      border-radius: var(--radius-md);
      box-shadow: var(--shadow-tooltip);
      color: var(--color-text-inverse);
      text-align: center;
      z-index: 10;
    }
    :host(:hover) .popover,
    :host(:focus-within) .popover {
      display: flex;
    }

    .popover-title {
      margin: 0;
      font-size: var(--font-size-sm);
      line-height: var(--line-height-sm);
      font-weight: var(--font-weight-bold);
    }
    .popover-description {
      margin: 0;
      font-size: var(--font-size-xs);
      line-height: var(--line-height-xs);
      font-weight: var(--font-weight-regular);
    }

    /* dyinggasp — familia support */
    :host([type="dyinggasp"]) .chip {
      background: var(--color-bg-info);
      border-color: var(--color-interactive-secondary);
      color: var(--color-interactive-secondary);
    }
    :host([type="dyinggasp"]:hover) .chip {
      background: var(--color-support-200);
    }
    :host([type="dyinggasp"]) .popover {
      background: var(--color-text-info);
    }

    /* inconsistency — familia error */
    :host([type="inconsistency"]) .chip {
      background: var(--color-bg-error);
      border-color: var(--color-border-error);
      color: var(--color-border-error);
    }
    :host([type="inconsistency"]:hover) .chip {
      background: var(--color-error-200);
    }
    :host([type="inconsistency"]) .popover {
      background: var(--color-interactive-danger);
    }

    /* different-integration — familia warning */
    :host([type="different-integration"]) .chip {
      background: var(--color-bg-warning);
      border-color: var(--color-border-warning);
      color: var(--color-border-warning);
    }
    :host([type="different-integration"]:hover) .chip {
      background: var(--color-warning-200);
    }
    :host([type="different-integration"]) .popover {
      background: var(--color-warning-600);
    }
  </style>
  <span class="chip" tabindex="0">
    <slot></slot>
  </span>
  <div class="popover">
    <p class="popover-title"></p>
    <p class="popover-description"></p>
  </div>
`;

class AresTooltipFlag extends HTMLElement {
  static get observedAttributes() {
    return ['type', 'creador'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(TEMPLATE.content.cloneNode(true));
    this._title = this.shadowRoot.querySelector('.popover-title');
    this._description = this.shadowRoot.querySelector('.popover-description');
  }

  connectedCallback() {
    this._sync();
  }

  attributeChangedCallback() {
    this._sync();
  }

  _sync() {
    const copy = COPY[this.getAttribute('type')];
    this._title.textContent = copy ? copy.title : '';
    if (!copy) {
      this._description.textContent = '';
    } else if (typeof copy.description === 'function') {
      this._description.textContent = copy.description(this.getAttribute('creador'));
    } else {
      this._description.textContent = copy.description;
    }
  }
}

if (!customElements.get('ares-tooltip-flag')) {
  customElements.define('ares-tooltip-flag', AresTooltipFlag);
}
})();
