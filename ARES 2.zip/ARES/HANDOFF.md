# HANDOFF.md — ARES

---

Se revisó toda la carpeta del proyecto (no solo el código fuente) buscando cualquier cosa que no aportara al handoff. Se eliminó:

| Eliminado                              | Por qué                                                                                                                                                                    |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `.DS_Store`                            | Metadata de Finder de macOS, sin relación con el proyecto.                                                                                                                 |
| `.claude/` (con `settings.local.json`) | Configuración local de la herramienta de IA usada durante el desarrollo (permisos de sesión, comandos aprobados) — no aporta nada a un desarrollador ni al proyecto en sí. |

No se encontró nada más que limpiar: no hay `node_modules/`, `package.json`, `.git/`, archivos `*_v2`/`*_old`/`*-backup`, ni archivos de prueba/scratch sueltos en la carpeta. El proyecto ya estaba limpio.

**Una carpeta que NO se eliminó pero podría parecer candidata:** `icons/` (24 SVG + 1 PNG). Ningún componente la carga por URL — todos los íconos se usan inline (`<svg>` embebido directo en el JS del componente, ver sección 9). Se dejó porque varios componentes la referencian en su documentación como la fuente original de esos SVG (ej. `ares-icon-button.js`: "Usar los SVG de icons/ic-close.svg... como contenido inline, no como src de `<img>`"). Sirve como biblioteca de referencia/actualización de íconos, no la carga el navegador en ningún momento.

**Nada quedó en la lista de "no estoy seguro, pregunto antes de borrar"** — el resto de los ~57 archivos del proyecto está todos activamente referenciado (ver árbol en sección 2).

**Bug encontrado y corregido durante esta revisión:** en `types.js`, un comentario JSDoc había quedado mal cerrado (el bloque de `IncidenteEstado` no tenía `*/` de cierre, lo que arrastraba el siguiente bloque `VnoAfectado` dentro del mismo comentario). No rompía nada en tiempo de ejecución (`types.js` no se carga vía `<script>`, es documentación pura), pero sí rompía el autocompletado/hover de tipos en el editor. Ya está corregido.

---

## 1. Stack técnico

- **HTML5** + **JavaScript vanilla (ES6+)** — sin framework (nada de React/Vue/Angular/jQuery).
- **Web Components nativos**: Custom Elements v1 (`class X extends HTMLElement`, `customElements.define(...)`) + Shadow DOM (`attachShadow({mode:'open'})`) para encapsular el CSS de cada componente.
- **CSS puro** con Custom Properties (variables) como sistema de design tokens (`tokens.css`).
- **`sessionStorage`** (Web Storage API) para persistir estado entre las dos pantallas (ver `estado-store.js`).
- **JSDoc** (`types.js`) — solo documentación de tipos, no hay TypeScript compilando nada.

**Dependencias externas: 1.** No hay `npm`/`package.json`/`node_modules` ni ícono-sets externos (los SVG son inline, ver sección 9), pero ambos HTML cargan la tipografía **Inter** desde Google Fonts vía CDN:

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
  href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap"
  rel="stylesheet"
/>
```

**Correr el proyecto localmente:**

Basta con abrir cualquiera de los 2 HTML directo en el navegador (doble clic, o arrastrar al navegador) — **no se necesita servidor**, porque justamente se evitó `type="module"` para que funcione bajo `file://`. (Sí se necesita conexión a internet para que cargue la tipografía Inter vía CDN — ver dependencia externa arriba.)

```bash
open bandeja.html
```

Si se prefiere servir por HTTP (ej. para probar con DevTools de red, o si el navegador bloquea algo bajo `file://` por política local), cualquier servidor estático simple sirve:

```bash
python3 -m http.server 8080
# luego abrir http://localhost:8080/bandeja.html
```

---

## 2. Estructura de archivos

```
ARES/
├── bandeja.html              Pantalla "Bandeja de incidencias" (tabs Pendientes / En Curso / Histórico)
├── bandeja.js                 Lógica de bandeja.html: filtros, búsqueda, tabs, banner, modales de Tomar INC/Liberar
├── gestion-incidencia.html    Pantalla de detalle de una incidencia (afectación, evidencia, alarmas, VNOs, ruta física)
├── gestion-incidencia.js      Lógica de gestion-incidencia.html: stats, tabla de alarmas paginada, modales de evidencia/validación
├── mock-data-bandeja.js       DATA-INPUT — mock de las incidencias que usa bandeja.html (ver sección 7 para reemplazarlo)
├── mock-data-gestion.js       DATA-INPUT — mock del detalle + alarmas que usa gestion-incidencia.html
├── estado-store.js            Capa de persistencia en sessionStorage compartida entre las 2 pantallas (ver sección 9)
├── types.js                    Solo JSDoc — typedefs de la forma de cada `.data` que consume cada componente
├── tokens.css                  Design tokens: color, tipografía, spacing, radios, sombras (CSS Custom Properties)
├── components/                 Los 20 Web Components (`ares-*`) — ver tabla completa en sección 3
│   ├── ares-alarm-row.js
│   ├── ares-alarma-badge.js
│   ├── ares-assignment-modal.js
│   ├── ares-button.js
│   ├── ares-count-badge.js
│   ├── ares-evidence-modal.js
│   ├── ares-gestor-badge.js
│   ├── ares-icon-button.js
│   ├── ares-incident-row.js
│   ├── ares-incident-summary.js
│   ├── ares-kpi-bar-detallada.js
│   ├── ares-kpi-bar-resumen.js
│   ├── ares-problema-tag.js
│   ├── ares-release-modal.js
│   ├── ares-sidebar.js
│   ├── ares-status-badge.js
│   ├── ares-tab-button.js
│   ├── ares-tooltip-flag.js
│   ├── ares-validation-bar.js
│   └── ares-validation-modal.js
└── icons/                      Biblioteca de íconos SVG fuente (+ 1 logo PNG) — de referencia, no se cargan por URL (ver sección 0)
```

Cada `.html` carga sus scripts en este orden fijo (importa respetarlo si se agrega algo nuevo, porque son scripts clásicos sin módulos y algunos dependen de que el anterior ya haya definido su custom element o su global):

1. Los componentes `ares-*.js` que esa pantalla usa.
2. `estado-store.js`.
3. Su `mock-data-*.js` correspondiente.
4. Su shell (`bandeja.js` / `gestion-incidencia.js`).

---

## 3. Tabla de componentes

| Componente               | Atributos                                                                                                                                                            | Slots                                           | Eventos                                                             | `.data` (ver types.js)                 |
| ------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------- | ------------------------------------------------------------------- | -------------------------------------- |
| `ares-button`            | `intent` ("primary"\|"secondary"\|"destructive"), `tone` (solo con primary: "brand"\|"success"), `disabled` (no aplica a primary)                                    | default (texto), `icon-start`, `icon-end`       | —                                                                   | —                                      |
| `ares-icon-button`       | `variant` ("neutral"\|"brand"\|"search"), `label` (aria-label, obligatorio), `disabled`, `tooltip` (texto flotante en hover)                                         | default (ícono), `text` (solo variant="search") | —                                                                   | —                                      |
| `ares-tab-button`        | `active`, `count`                                                                                                                                                    | `icon`, default (texto)                         | —                                                                   | —                                      |
| `ares-tooltip-flag`      | `type` ("dyinggasp"\|"inconsistency"\|"different-integration"), `creador` (solo con type="different-integration" — qué integración creó la alarma, ej. "nokia.nfmp") | default (ícono)                                 | —                                                                   | —                                      |
| `ares-status-badge`      | `status` ("pendiente"\|"aprobada"\|"rechazada"\|"en-curso")                                                                                                          | —                                               | —                                                                   | —                                      |
| `ares-problema-tag`      | `tipo` ("pon-loss"\|"cto-indisponible"\|"gasp")                                                                                                                      | —                                               | —                                                                   | —                                      |
| `ares-alarma-badge`      | `estado` ("abierto"\|"cerrado")                                                                                                                                      | —                                               | —                                                                   | —                                      |
| `ares-gestor-badge`      | `fabricante` ("nokia"\|"uaa"\|"huawei"\|"sin-respuesta")                                                                                                             | default (texto del conteo, ej. "Nokia · 38")    | —                                                                   | —                                      |
| `ares-count-badge`       | —                                                                                                                                                                    | default (número/texto)                          | —                                                                   | —                                      |
| `ares-sidebar`           | `expandido`                                                                                                                                                          | —                                               | `ares-toggle` (detail: `{expandido}`), `ares-nav-incidentes`        | `SidebarData`                          |
| `ares-incident-summary`  | —                                                                                                                                                                    | `trailing` (contenido extra al final)           | —                                                                   | `IncidentSummary`                      |
| `ares-incident-row`      | `variante` ("pendiente"\|"en-curso"\|"historico")                                                                                                                    | —                                               | `ares-tomar-inc` (detail: `{id}`), `ares-detalles` (detail: `{id}`) | `IncidentRowData` (incluye `esPropia`) |
| `ares-alarm-row`         | —                                                                                                                                                                    | —                                               | `ares-ver-evidencia` (detail: `{id}`)                               | `AlarmRowData`                         |
| `ares-kpi-bar-detallada` | — (el fondo gris es solo `:hover`, no un atributo — ver nota debajo de la tabla)                                                                                     | —                                               | —                                                                   | `KpiBarDetalladaData`                  |
| `ares-kpi-bar-resumen`   | `titulo`, `valor`                                                                                                                                                    | —                                               | —                                                                   | —                                      |
| `ares-validation-bar`    | `puede-gestionar`                                                                                                                                                    | —                                               | `ares-aprobar-consolidacion`, `ares-rechazar-consolidacion`         | `ValidationBarData`                    |
| `ares-assignment-modal`  | `open`, `modo` ("confirmar"\|"cambio")                                                                                                                               | —                                               | `ares-cancel`, `ares-gestionar` (detail: `{id}`)                    | `AssignmentModalData`                  |
| `ares-release-modal`     | `open`                                                                                                                                                               | —                                               | `ares-cancel`, `ares-liberar` (detail: `{id}`)                      | `ReleaseModalData`                     |
| `ares-validation-modal`  | `open`, `accion` ("aprobar"\|"rechazar")                                                                                                                             | —                                               | `ares-cancel`, `ares-confirmar` (detail: `{id, accion}`)            | `ValidationModalData`                  |
| `ares-evidence-modal`    | `open`                                                                                                                                                               | —                                               | `ares-cancel`                                                       | `EvidenceModalData`                    |

Todos siguen el mismo patrón interno: Shadow DOM abierto, `_upgradeProperty('data')` en el constructor (evita que `.data` asignado antes del upgrade del custom element quede como own-property sin pasar por el setter), y `attributeChangedCallback`/`connectedCallback` para reaccionar a cambios de atributo.

---

## 4. Matriz de estados — qué pantalla usa qué variante

| Componente / atributo                             | Valor                                                                                | Dónde aparece                                                                                                                              |
| ------------------------------------------------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------ |
| `ares-incident-row[variante]`                     | `pendiente`                                                                          | `bandeja.html`, tab **Pendientes** únicamente (con botón "Tomar INC")                                                                      |
|                                                   | `en-curso`                                                                           | `bandeja.html`, tab **En Curso · Equipo** únicamente (con badge/avatar celeste si `esPropia`)                                              |
|                                                   | `historico`                                                                          | `bandeja.html`, tab **Histórico** únicamente (con subfiltro Todas/Aprobadas/Rechazadas)                                                    |
| `ares-status-badge[status]`                       | `pendiente`/`en-curso`/`aprobada`/`rechazada`                                        | Dentro de `ares-incident-summary`, en ambas pantallas (filas de bandeja + header de gestión)                                               |
| `ares-alarma-badge[estado]`                       | `abierto`/`cerrado`                                                                  | Solo `gestion-incidencia.html`, columna "Estado" de la tabla de alarmas                                                                    |
| `ares-tooltip-flag[type]`                         | los 3 tipos                                                                          | Solo `gestion-incidencia.html`, junto al ID de cada fila de alarma (0, 1 o varios simultáneos)                                             |
| `ares-gestor-badge[fabricante]`                   | los 4 valores                                                                        | Solo `gestion-incidencia.html`, panel "Evidencia"                                                                                          |
| `ares-kpi-bar-detallada` / `ares-kpi-bar-resumen` | —                                                                                    | Solo `bandeja.html`, header (KPI row) — **ambos coexisten**, no es uno u otro                                                              |
| `ares-validation-bar[puede-gestionar]`            | true/false                                                                           | Solo `gestion-incidencia.html`, barra inferior — true solo si la incidencia está en-curso **y** asignada al usuario actual (ver sección 5) |
| `ares-assignment-modal[modo]`                     | `confirmar` (usuario sin incidencia activa) / `cambio` (usuario ya tiene una tomada) | Solo `bandeja.html`, al hacer click en "Tomar INC"                                                                                         |
| `ares-release-modal`                              | —                                                                                    | Solo `bandeja.html`, al hacer click en "Liberar" del banner                                                                                |
| `ares-validation-modal[accion]`                   | `aprobar`/`rechazar`                                                                 | Solo `gestion-incidencia.html`, al hacer click en los botones de la barra de validación                                                    |
| `ares-evidence-modal`                             | —                                                                                    | Solo `gestion-incidencia.html`, al hacer click en el ícono de evidencia de una fila de alarma                                              |
| `ares-sidebar[expandido]`                         | true/false                                                                           | Ambas pantallas, mismo componente, estado independiente por pantalla (no se persiste entre navegaciones)                                   |
| `ares-tab-button[active]`                         | —                                                                                    | Solo `bandeja.html`, 3 instancias (una por tab)                                                                                            |

---

## 5. Puntos de integración de datos (DATA-INPUT)

Todo campo marcado `DATA-INPUT` en el código (JSDoc en `types.js` + mocks) no tiene todavía un contrato de API real — hoy se genera en el cliente. Agrupado por sistema de origen tal como está documentado en las cabeceras de los mocks:

### ServiceNow

- Incidencias: `id`, `estado`, `responsable` — `mock-data-bandeja.js`, tipo `IncidentSummary`/`Responsable` (`types.js`).
- Registro final aprobado/rechazado de una consolidación — `mock-data-gestion.js`, `IncidentDetalle.estado`.
- Fechas de incidencia (`fechaInicioReal`, `fechaCreacion`) — `types.js` (`IncidentSummary`).
- `masDe24Horas` / `enTerreno` (alimentan 2 KPIs del header de bandeja) — **sin fuente real confirmada todavía**; el propio mock (`mock-data-bandeja.js`) señala que probablemente requiera un campo nuevo en ServiceNow.

### Nokia / Huawei (vía BluePlanet)

- Alarmas: `id`, `creado`, `estado`, `ciAfectado` — `mock-data-gestion.js` / `AlarmRowData` (`types.js`).
- Cobertura de evidencia por fabricante ("gestores": nokia/huawei directamente) — `IncidentDetalle.gestores`.
- `creadorAlarma` — qué integración creó la alarma cuando no fue BluePlanet (ej. "nokia.nfmp", "huawei.u2000", "osp.manual"), solo relevante si `flags` incluye `"different-integration"` — `AlarmRowData` (`types.js`), consumido por `ares-tooltip-flag[creador]`.

### UAA

- Cobertura de evidencia, fabricante `"uaa"` — `IncidentDetalle.gestores` (mismo campo que Nokia/Huawei, valor `fabricante: "uaa"`).
- `"sin-respuesta"` es el caso cuando ningún fabricante contesta (no es un sistema de origen en sí, es la ausencia de respuesta de los anteriores).

### OSP

- Ruta física / raíz común (`olt`, `cap`, `fibraTroncal`, `slots`, `puertosPon`) — `IncidentDetalle.rutaFisica` (`types.js`).

### Databricks

- Agregados de afectación/alarmas para el KPI bar de `bandeja.html` (afectación total, total alarmas).
- Resumen de incidente en el detalle: `afectacionTotal`, `afectacionReales`, `alarmasTotal`, `alarmasAbiertas` — `IncidentSummary`/`IncidentDetalle`.
- `evidenciaCapturadas` / `evidenciaSinCapturar` / `evidenciaCobertura` — deben coincidir con el conteo real de alarmas con/sin evidencia (ya se calculan así en el mock actual, ver sección 7).

### CMDB

- VNOs afectadas: `carrier`, `codigo`, `count` — `VnoAfectado` (`types.js`), usado en `IncidentSummary.vnos`, `KpiBarDetalladaData.vnos` y el panel "VNOs Afectados" de gestión.

### Sesión autenticada (login/SSO — sistema no definido aún)

- `Responsable` del usuario actual (`iniciales`, `nombre`, `rol`) — `currentUser.responsable` en `mock-data-bandeja.js`. Hoy es un valor fijo (`RESPONSABLES[0]`); el día que haya login real, basta reemplazar este objeto (ver sección 7).
- `incidenciaActivaId` (cuál incidencia tiene tomada el usuario) — hoy vive en `sessionStorage` vía `estado-store.js`; en producción debería resolverse desde el backend de sesión, no en el cliente.

---

## 6. Cómo reemplazar los mocks por datos reales

Los componentes **nunca** saben de dónde viene su data — todo llega por `.data =` o atributos HTML. Reemplazar un mock no requiere tocar ningún componente, solo el archivo de mock y, en un caso, una función puntual.

### `bandeja.html` / `mock-data-bandeja.js`

`bandeja.js` solo lee 2 globals de este archivo: `mockDataBandeja` (array) y `currentUser` (objeto). Pasos:

1. Reemplazar la generación en memoria de `mockDataBandeja` por un `fetch()` (o la llamada que corresponda) a la API real, que devuelva un array de objetos con la forma de `IncidentSummary` (ver `types.js`) — mismos nombres de campo exactos: `id`, `estado`, `tipoIncidente`, `fechaInicioReal`, `fechaCreacion`, `afectacionTotal`, `afectacionReales`, `alarmasTotal`, `alarmasAbiertas`, `vnos`, más `responsable` (solo en incidencias en-curso/histórico), `masDe24Horas`, `enTerreno`.
2. Reemplazar `currentUser` por los datos de la sesión real: `{ responsable: {iniciales, nombre, rol}, incidenciaActivaId }`.
3. Como el `fetch` es asíncrono y hoy todo el archivo es síncrono (se ejecuta y ya deja `mockDataBandeja`/`currentUser` listos antes de que corra `bandeja.js`), hay que envolver el `fetch` + la llamada a las funciones de render en una función `async` y llamarla al final, en vez de dejar que `bandeja.js` asuma que los datos ya están listos apenas carga.
4. `estado-store.js` puede seguir existiendo tal cual (sigue siendo útil para que la navegación entre pantallas no pierda estado dentro de la sesión del navegador), o reemplazarse por llamadas reales al backend si "tomar/liberar/aprobar/rechazar" deben persistir server-side.

### `gestion-incidencia.html` / `mock-data-gestion.js`

`gestion-incidencia.js` solo usa `resolverDatosIncidencia(id)`, que devuelve `{ incidenteDetalle, alarmas }`. Pasos:

1. Reemplazar el cuerpo de `resolverDatosIncidencia(id)` para que, en vez de generar datos desde el seed, haga un `fetch()` a la API real usando el `id` recibido (que ya viene correctamente desde `?id=` en la URL, ver sección 8) y devuelva un objeto con la forma de `IncidentDetalle` (ver `types.js`) + un array de `AlarmRowData`.
2. Igual que en bandeja: como hoy es síncrono, hay que adaptar el punto de entrada del archivo para esperar el `fetch` (async/await) antes de llamar a `renderHeader()`, `renderEvidencia()`, etc.
3. `evidenciaCapturadas`/`evidenciaSinCapturar`/`evidenciaCobertura` deben seguir calculándose (o venir ya calculados de la API) de forma que coincidan con el conteo real de `evidenciaDisponible` de las alarmas — si la API los entrega desincronizados, se reproduce el bug que ya se corrigió en el mock (ver sección 8, D4).
4. `puedeGestionar` debe calcularse en el backend según el estado real del ticket y quién lo tiene asignado — **no inferirlo en el cliente** comparando contra `sessionStorage` como hace el mock hoy (eso es un parche válido para un prototipo sin backend, no para producción).

Ningún componente (`ares-*`) requiere cambios en ninguno de los dos casos.

---

## 7. Convenciones del proyecto

Todo componente se nombra `ares-<algo>` (prefijo obligatorio para custom elements — el guion es requerido por la spec de Custom Elements) y vive en `components/` como un archivo IIFE independiente (`(function () { ... })();`) que se auto-registra con `customElements.define(...)` si no existe ya — esto es necesario porque los scripts se cargan como clásicos (no módulos) y comparten el mismo scope global, así que cada archivo encierra sus propios `const TEMPLATE`/`class` para no chocar con los de otro componente. El **color, spacing, tipografía, radios y sombras nunca se hardcodean** — todo sale de las CSS Custom Properties definidas en `tokens.css` (ej. `var(--color-bg-brand)`, `var(--space-2)`); si hace falta un valor nuevo, se agrega como token ahí, no como número suelto en el componente. Por último, dos comentarios-tag hay que respetar y mantener al tocar el código: `DATA-INPUT` marca cualquier dato que hoy es mock pero en producción vendría de un sistema externo (ver sección 5 para la lista completa agrupada por sistema), y `DISEÑO-PENDIENTE` marca una decisión de diseño todavía sin confirmar (sección 6) — ninguno de los dos debería removerse sin resolver lo que señalan.
